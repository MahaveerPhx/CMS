/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['localhost', 'cms.phx.co.in'],
  },
};

export default nextConfig;
