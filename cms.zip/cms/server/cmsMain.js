import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";

import AuthRoutes from "./routes/AuthRoutes.js";
import MasterRoutes from "./routes/MasterRoutes.js";
import WebsiteRoutes from "./routes/WebsiteRoutes.js";

dotenv.config();
const app = express();


app.use(
  cors({
    origin: "http://localhost:3000", // Replace with your frontend URL
    credentials: true, // Allow cookies to be sent
  })
);
app.use(express.json());

app.use(express.urlencoded({ extended: true }));

app.use(cookieParser());


app.use("/api/auth-api/", AuthRoutes);
app.use("/api/master-api/", MasterRoutes);
app.use("/api/web-api/", WebsiteRoutes);
app.use('/assets/articleImage/', express.static("./assets/articleImage/"));

// app.use("/uploads", express.static("uploads")); 

app.listen(process.env.PORT, () => {
    console.log(
      `server started on ${process.env.PORT} ${process.env.SERVER_HOST}`
    );
});
