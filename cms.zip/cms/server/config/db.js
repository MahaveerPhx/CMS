// config/db.js

import mysql from "mysql2/promise";
import dotenv from "dotenv";

// Load environment variables from .env file
dotenv.config();

let dbpool;

export const createPool = (databaseDetail) => {
  dbpool = mysql.createPool({
    host: databaseDetail?.host || process.env.MASTER_DB_HOST,
    user: databaseDetail?.user || process.env.MASTER_DB_USER,
    password: databaseDetail?.password || process.env.MASTER_DB_PASS,
    database: databaseDetail?.databaseName || process.env.MASTER_DB_NAME,
  });
};

export const getPool = () => {
  if (!dbpool) {
    throw new Error("Database connection pool has not been initialized.");
  }
  return dbpool;
};

// Set the initial pool to master credentials
createPool();
