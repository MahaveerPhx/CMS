import { createPool, getPool } from "../config/db.js";
import jwt from "jsonwebtoken";
const JWT_SECRET = process.env.JWT_SECRET; // Replace with a strong secret key
const COOKIE_NAME = "authToken"; // Name of the cookie

export const switchPanel = async (req, res) => {
    const { host, user, password, databaseName, isMaster } = req.body;

    try {
        if (isMaster) {

            createPool({
                host: process.env.MASTER_DB_HOST,
                user: process.env.MASTER_DB_USER,
                password: process.env.MASTER_DB_PASS,
                databaseName: process.env.MASTER_DB_NAME
            });

        } else {
            
            createPool({ host, user, password, databaseName });

        }

        res.status(200).json({ success: true, message: "Switched database successfully." });
    } catch (error) {
        console.error('Error switching database:', error);
        res.status(500).json({ success: false, message: 'Failed to switch database' });
    }
};

export async function login(req, res) {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
    }

    const query = "SELECT * FROM admins WHERE email = ? AND password = ?";

    try {
        const pool = getPool();
        const [results] = await pool.query(query, [email, password]);

        if (results.length > 0) {
          const admin = results[0];

          // Generate JWT token with admin role and other info
          const token = jwt.sign(
            { id: admin.id, email: admin.email, role: admin.role },
            JWT_SECRET,
            { expiresIn: "30d" } // Token expires in 1 day
          );

          // Set the cookie with the token
          res.cookie(COOKIE_NAME, token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            maxAge: 30 * 24 * 60 * 60 * 1000,
            sameSite: "strict",
          });
          
          return res.status(200).json({
            success: true,
            message: "Login successful",
            admin: {
              id: admin.id,
              email: admin.email,
              role: admin.role,
              name: admin.name,
            },
            token,
          });
        } else {
            return res.status(401).json({ error: "Invalid email or password" });
        }
    } catch (error) {
        console.error("Error during login:", error);
        return res.status(500).json({ error: "Database query failed" });
    }
}
