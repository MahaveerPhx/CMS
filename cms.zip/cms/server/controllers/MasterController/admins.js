import { getPool } from "../../config/db.js"

//admins api
export async function createAdmin (req, res) {
  const { name, password, email, role } = req.body;

  try {
    const pool = getPool();
    const [result] = await pool.query(
      'INSERT INTO admins (name, password, email, role) VALUES (?, ?, ?, ?)',
      [name, password, email, role]
    );
    res.status(201).json({ success: true, message: 'Admin created successfully', id: result.insertId });
  } catch (error) {
    console.error('Error creating admin:', error);
    res.status(500).json({ success: false, message: 'Failed to create admin' });
  }
};


export async function getAdmins (req, res) {
  const { page = 1, limit = 10 } = req.query;

  try {
    const pool = getPool();
    // Calculate offset for pagination
    const offset = (page - 1) * limit;

    // Query to fetch admins with pagination
    const [admins] = await pool.query(
      'SELECT * FROM admins LIMIT ?, ?',
      [parseInt(offset), parseInt(limit)]
    );

    // Query to get the total number of admins
    const [[totalAdminsResult]] = await pool.query('SELECT COUNT(*) AS total FROM admins');
    const totalAdmins = totalAdminsResult.total;

    res.status(200).json({
      success: true,
      admins,
      totalItems: totalAdmins,
      currentPage: page,
      totalPages: Math.ceil(totalAdmins / limit)
    });
  } catch (error) {
    console.error('Error fetching admins:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch admins' });
  }
};


export async function updateAdmin (req, res) {
  const { id,name, password, email, role } = req.body;

  try {
    const pool = getPool();
    const [result] = await pool.query(
      'UPDATE admins SET name = ?, password = ?, email = ?, role = ? WHERE id = ?',
      [name, password, email, role, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Admin not found' });
    }

    res.status(200).json({ success: true, message: 'Admin updated successfully' });
  } catch (error) {
    console.error('Error updating admin:', error);
    res.status(500).json({ success: false, message: 'Failed to update admin' });
  }
};


export async function deleteAdmin (req, res) {
  const { id } = req.body;

  try {
    const pool = getPool();
    const [result] = await pool.query('DELETE FROM admins WHERE id = ?', [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Admin not found' });
    }

    res.status(200).json({ success: true, message: 'Admin deleted successfully' });
  } catch (error) {
    console.error('Error deleting admin:', error);
    res.status(500).json({ success: false, message: 'Failed to delete admin' });
  }
};
