import { getPool } from "../../config/db.js"


export async function getMasterData(req, res) {
    try {
        const pool = getPool();

        const [websiteCount] = await pool.query('SELECT COUNT(*) AS count FROM websites');
        const [adminCount] = await pool.query('SELECT COUNT(*) AS count FROM admins');

        const data = {
            adminsCount: adminCount[0].count,
            websitesCount: websiteCount[0].count,
        };


        res.status(200).json({ success: true, data });
    } catch (error) {
        console.error('Error fetching data:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch data' });
    }
}
