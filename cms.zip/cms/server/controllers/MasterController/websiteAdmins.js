import { getPool } from "../../config/db.js"

//websites apis

export async function getWebsiteAdmins(req, res) {
    const { page = 1, limit = 10 } = req.body;

    try {
        const pool = getPool();
        // Calculate offset for pagination
        const offset = (page - 1) * limit;

        // Query to fetch articles with authorName and categoryName
        const query = `
            SELECT 
                websiteadmins.*, 
                websites.name as websiteName, 
                admins.name as adminName
            FROM websiteadmins
            LEFT JOIN websites ON websiteadmins.websiteId = websites.id
            LEFT JOIN admins ON websiteadmins.adminId = admins.id
            LIMIT ?, ?
        `;
        const queryParams = [offset, parseInt(limit)];

        // Query to get the total number of articles
        const countQuery = 'SELECT COUNT(*) as totalItems FROM websiteadmins';

        const [websiteAdmins] = await pool.query(query, queryParams);
        const [totalItemsResult] = await pool.query(countQuery);
        const totalItems = totalItemsResult[0].totalItems;

        res.status(200).json({ success: true, websiteAdmins, totalItems, currentPage: page, totalPages: Math.ceil(totalItems / limit) });
    } catch (error) {
        console.error('Error fetching website admins:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch website admins' });
    }
};


export async function addWebsiteAdmin(req, res) {
    const { websiteId, adminId, role } = req.body;
    try {
        const pool = getPool();
        const query = 'INSERT INTO websiteadmins (websiteId, adminId, role) VALUES (?, ?, ?)';
        await pool.query(query, [websiteId, adminId, role]);
        res.status(201).json({ success: true, message: 'website admins created successfully' });
    } catch (error) {
        console.error('Error creating website:', error);
        res.status(500).json({ success: false, message: 'Failed to create website admins' });
    }
};




export async function updateWebsiteAdmin(req, res) {
    const { id, websiteId, adminId, role } = req.body;
    try {
        const pool = getPool();
        const query = `
      UPDATE websiteadmins 
      SET websiteId = ?, adminId = ?, role = ?
      WHERE id = ?
    `;
        await pool.query(query, [websiteId, adminId, role, id]);
        res.status(200).json({ success: true, message: 'website admins updated successfully' });
    } catch (error) {
        console.error('Error updating website:', error);
        res.status(500).json({ success: false, message: 'Failed to update website admins' });
    }
};

export async function deleteWebsiteAdmin(req, res) {
    const { id } = req.body;
    try {
        const pool = getPool();
        const query = 'DELETE FROM websiteadmins WHERE id = ?';
        await pool.query(query, [id]);
        res.status(200).json({ success: true, message: 'website admins deleted successfully' });
    } catch (error) {
        console.error('Error deleting website:', error);
        res.status(500).json({ success: false, message: 'Failed to delete website admins' });
    }
};





