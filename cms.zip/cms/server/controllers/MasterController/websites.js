import { getPool } from "../../config/db.js";

//websites apis
export async function createWebsite(req, res) {
  const { name, domain, host, user, password, databaseName } = req.body;
  try {
    const pool = getPool();
    const query =
      "INSERT INTO websites (name, domain, host, user, password, databaseName) VALUES (?, ?, ?, ?, ?, ?)";
    await pool.query(query, [name, domain, host, user, password, databaseName]);
    res
      .status(201)
      .json({ success: true, message: "Website created successfully" });
  } catch (error) {
    console.error("Error creating website:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to create website" });
  }
}

export async function getWebsites(req, res) {
  const { page = 1, limit = 10, domain = "" } = req.body;

  // Calculate the offset for pagination
  const offset = (page - 1) * limit;

  try {
    const pool = getPool();
    let query, queryParams, countQuery, countParams;

    if (domain) {
      // Query to fetch websites with domain filtering
      query = "SELECT * FROM websites WHERE domain LIKE ? LIMIT ?, ?";
      queryParams = [`%${domain}%`, parseInt(offset), parseInt(limit)];
      countQuery =
        "SELECT COUNT(*) as totalItems FROM websites WHERE domain LIKE ?";
      countParams = [`%${domain}%`];
    } else {
      // Query to fetch all websites
      query = "SELECT * FROM websites LIMIT ?, ?";
      queryParams = [parseInt(offset), parseInt(limit)];
      countQuery = "SELECT COUNT(*) as totalItems FROM websites";
      countParams = [];
    }

    const [websites] = await pool.query(query, queryParams);
    const [countResult] = await pool.query(countQuery, countParams);
    const totalItems = countResult[0].totalItems;

    //fetching column names from the websites table
    const [columns] = await pool.query("SHOW COLUMNS FROM websites");
    const columnNames = columns.map((column) => column.Field);

    res.status(200).json({
      success: true,
      websites,
      totalItems,
      currentPage: parseInt(page),
      totalPages: Math.ceil(totalItems / limit),
      columnNames,
    });
  } catch (error) {
    console.error("Error fetching websites:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch websites" });
  }
}


export async function getAllWebsiteDetails(req, res) {
  try {
    const pool = getPool();

    let query;

    // Query to fetch all websites
    query = "SELECT * FROM websites";

    const [websiteAllDetails] = await pool.query(query);

    res.status(200).json({
      websiteAllDetails,
    });
  } catch (error) {
    console.error("Error fetching website data:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch website data" });
  }
}

export async function updateWebsite(req, res) {
  const { id, name, domain, host, user, password, databaseName } = req.body;
  try {
    const pool = getPool();
    const query = `
      UPDATE websites 
      SET name = ?, domain = ?, host = ?, user = ?, password = ?, databaseName = ? 
      WHERE id = ?
    `;
    await pool.query(query, [
      name,
      domain,
      host,
      user,
      password,
      databaseName,
      id,
    ]);
    res
      .status(200)
      .json({ success: true, message: "Website updated successfully" });
  } catch (error) {
    console.error("Error updating website:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to update website" });
  }
}

export async function deleteWebsite(req, res) {
  const { id } = req.body;
  try {
    const pool = getPool();
    const query = "DELETE FROM websites WHERE id = ?";
    await pool.query(query, [id]);
    res
      .status(200)
      .json({ success: true, message: "Website deleted successfully" });
  } catch (error) {
    console.error("Error deleting website:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to delete website" });
  }
}
