import { getPool } from "../../config/db.js";

// Create a new ad
export async function createAd(req, res) {
  const {
    title, 
    description, 
    type, 
    ads_size, 
    image_path, 
    code, 
    ad_url, 
    ad_page, 
    ad_section, 
    start_date, 
    end_date, 
    status 
  } = req.body;

  try {
    const pool = getPool();
    const [result] = await pool.query(
      'INSERT INTO ads (title, description, type, ads_size, image_path, code, ad_url, ad_page, ad_section, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [title, description, type, ads_size, image_path, code, ad_url, ad_page, ad_section, start_date, end_date, status]
    );

    res.status(201).json({ success: true, id: result.insertId, ...req.body });
  } catch (error) {
    console.error('Error creating ad:', error);
    res.status(500).json({ success: false, message: 'Failed to create ad' });
  }
}

// Get all ads with pagination
export async function getAds(req, res) {
  const { page = 1, limit = 10 } = req.query;

  try {
    const pool = getPool();
    const offset = (page - 1) * limit;

    const [ads] = await pool.query('SELECT * FROM ads LIMIT ?, ?', [offset, parseInt(limit)]);
    const [totalItemsResult] = await pool.query('SELECT COUNT(*) as totalItems FROM ads');
    const totalItems = totalItemsResult[0].totalItems;

    res.status(200).json({ success: true, ads, totalItems });
  } catch (error) {
    console.error('Error fetching ads:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch ads' });
  }
}

// Update an existing ad
export async function updateAd(req, res) {
  const {
    id, 
    title, 
    description, 
    type, 
    ads_size, 
    image_path, 
    code, 
    ad_url, 
    ad_page, 
    ad_section, 
    start_date, 
    end_date, 
    status 
  } = req.body;

  try {
    const pool = getPool();

    const [result] = await pool.query(
      'UPDATE ads SET title = ?, description = ?, type = ?, ads_size = ?, image_path = ?, code = ?, ad_url = ?, ad_page = ?, ad_section = ?, start_date = ?, end_date = ?, status = ? WHERE id = ?',
      [title, description, type, ads_size, image_path, code, ad_url, ad_page, ad_section, start_date, end_date, status, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Ad not found' });
    }

    res.status(200).json({ success: true, message: 'Ad updated successfully' });
  } catch (error) {
    console.error('Error updating ad:', error);
    res.status(500).json({ success: false, message: 'Failed to update ad' });
  }
}

// Delete an ad
export async function deleteAd(req, res) {
  const { id } = req.body;

  try {
    const pool = getPool();

    const [result] = await pool.query('DELETE FROM ads WHERE id = ?', [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Ad not found' });
    }

    res.status(200).json({ success: true, message: 'Ad deleted successfully' });
  } catch (error) {
    console.error('Error deleting ad:', error);
    res.status(500).json({ success: false, message: 'Failed to delete ad' });
  }
}