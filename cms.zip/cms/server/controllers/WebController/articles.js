import { getPool } from "../../config/db.js";
import multiparty from "multiparty";
import fs from "fs";
import path from "path";

//make article api functions
export async function createArticle(req, res) {
  const { title, content, authorId, categoryId, status = "draft" } = req.body;
  try {
    const pool = getPool();
    const [result] = await pool.query(
      "INSERT INTO articles (title, content, authorId, categoryId, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, NOW(), NOW())",
      [title, content, authorId, categoryId, status]
    );
    res.status(201).json({ success: true, id: result.insertId });
  } catch (error) {
    console.error("Error creating article:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to create article" });
  }
}

export async function getArticles(req, res) {
  const { page = 1, limit = 10 } = req.body;

  try {
    const pool = getPool();
    // Calculate offset for pagination
    const offset = (page - 1) * limit;

    // Query to fetch articles with authorName and categoryName
    const query = `
            SELECT 
                articles.*, 
                authors.name as authorName, 
                categories.name as categoryName
            FROM articles
            LEFT JOIN authors ON articles.authorId = authors.id
            LEFT JOIN categories ON articles.categoryId = categories.id
            ORDER BY articles.id DESC
            LIMIT ?, ?
        `;
    const queryParams = [offset, parseInt(limit)];

    // Query to get the total number of articles
    const countQuery = "SELECT COUNT(*) as totalItems FROM articles";

    // Query to get column names from articles table
    const columnQuery = "SHOW COLUMNS FROM articles";

    const [articles] = await pool.query(query, queryParams);
    const [totalItemsResult] = await pool.query(countQuery);
    const [columns] = await pool.query(columnQuery); // Fetch column names

    const totalItems = totalItemsResult[0].totalItems;

    // Extract column names from the result
    const columnNames = columns.map((column) => column.Field);

    res.status(200).json({
      success: true,
      articles,
      totalItems,
      currentPage: page,
      totalPages: Math.ceil(totalItems / limit),
      columnNames, // Add column names to the response
    });
  } catch (error) {
    console.error("Error fetching articles:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch articles" });
  }
}

export async function updateArticle(req, res) {
  const {
    id,
    title,
    content,
    image,
    authorId,
    categoryId,
    status,
    scheduleStartTime,
    scheduleEndTime,
    createdBy,
    updatedBy,
  } = req.body;

  if (!id) {
    return res.status(400).json({ success: false, message: "ID is required" });
  }

  try {
    const pool = getPool();
    const [result] = await pool.query(
      "UPDATE articles SET title = ?, content = ?, image = ?, authorId = ?, categoryId = ?, status = ?, scheduleStartTime = ?, scheduleEndTime = ?, createdBy = ?, updatedBy = ?, updatedAt = NOW() WHERE id = ?",
      [
        title,
        content,
        image,
        authorId,
        categoryId,
        status,
        scheduleStartTime,
        scheduleEndTime,
        createdBy,
        updatedBy,
        id,
      ]
    );

    if (result.affectedRows === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Article not found" });
    }

    res.status(200).json({ success: true, message: "Article updated" });
  } catch (error) {
    console.error("Error updating article:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to update article" });
  }
}

export async function deleteArticle(req, res) {
  const { id } = req.body;

  if (!id) {
    return res.status(400).json({ success: false, message: "ID is required" });
  }

  try {
    const pool = getPool();
    const [result] = await pool.query("DELETE FROM articles WHERE id = ?", [
      id,
    ]);
    if (result.affectedRows === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Article not found" });
      return;
    }
    res.status(200).json({ success: true, message: "Article deleted" });
  } catch (error) {
    console.error("Error deleting article:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to delete article" });
  }
}

export async function uploadImage(req, res) {
  const form = new multiparty.Form();

  form.parse(req, (err, fields, files) => {
    if (err) {
      console.error("Error parsing form data:", err);
      return res.status(500).json({ error: "Internal Server Error" });
    }

    try {
      const uploadDir = "./assets/articleImage/";
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }

      const file = files.upload && files.upload[0];
      if (!file) {
        console.error("No file found in the request.");
        return res.status(400).json({ error: "No file uploaded" });
      }

      const ext = path.extname(file.originalFilename);
      const newFileName = Date.now() + ext;
      const newPath = path.join(uploadDir, newFileName);

      fs.copyFileSync(file.path, newPath);

      return res.json({
        uploaded: true,
        url: `${process.env.SERVER_HOST}/assets/articleImage/${newFileName}`,
      });
    } catch (error) {
      console.error("Error saving file locally:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  });
}
