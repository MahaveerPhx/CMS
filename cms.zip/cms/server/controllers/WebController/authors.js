import { getPool } from "../../config/db.js"


// create Author API
export async function createAuthor(req, res) {
    const { name, email, bio, status, image } = req.body;
    console.log("req body", req.body);
    try {
        const pool = getPool();

        const [result] = await pool.query(
            'INSERT INTO authors (name, email, bio, status, image_name, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
            [name, email, bio, status, image]
        );

        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        console.error('Error creating author:', error);
        res.status(500).json({ success: false, message: 'Failed to create author' });
    }
}


// export async function getAuthors(req, res) {
//     const {  authorId = '', page = 1, limit = 10 } = req.query;
//     try {
//         const pool = getPool();

//         if(authorId) {
//             const [author] = await pool.query('SELECT * FROM authors WHERE id = ?', [authorId]);
//             if (author.length === 0) {
//                 return res.status(404).json({ success: false, message: 'Author not found' });
//             }

//             return res.status(200).json({ success: true, author: author[0].name });
//         }

//         const offset = (page - 1) * limit;
//         const [authors] = await pool.query('SELECT * FROM authors LIMIT ?, ?', [offset, parseInt(limit)]);
//         const [totalItemsResult] = await pool.query('SELECT COUNT(*) as totalItems FROM authors');
//         const totalItems = totalItemsResult[0].totalItems;
//         res.status(200).json({ success: true, authors, totalItems });
//     } catch (error) {
//         console.error('Error fetching authors:', error);
//         res.status(500).json({ success: false, message: 'Failed to fetch authors' });
//     }
// }


//get Author API
export async function getAuthors(req, res) {
    const { authorId = '', page = 1, limit = 10 } = req.query;

    try {
        const pool = getPool();

        if (authorId) {
            const [author] = await pool.query('SELECT * FROM authors WHERE id = ?', [authorId]);
            if (author.length === 0) {
                return res.status(404).json({ success: false, message: 'Author not found' });
            }

            return res.status(200).json({ success: true, author: author[0] });
        }

        const offset = (page - 1) * limit;
        const [authors] = await pool.query('SELECT * FROM authors LIMIT ?, ?', [offset, parseInt(limit)]);
        const [totalItemsResult] = await pool.query('SELECT COUNT(*) as totalItems FROM authors');
        const totalItems = totalItemsResult[0].totalItems;

        res.status(200).json({
            success: true,
            authors: authors.map(author => ({
                id: author.id,
                name: author.name,
                email: author.email,
                bio: author.bio,
                status: author.status,
                image_name: `${author.image_name}`, // Image path
            })),
            totalItems,
        });
    } catch (error) {
        console.error('Error fetching authors:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch authors' });
    }
}


// update authors API
export async function updateAuthor(req, res) {
    const { id, name, email, bio, status, image } = req.body;

    if (!id) {
        return res.status(400).json({ success: false, message: 'ID is required' });
    }

    try {
        const pool = getPool();

        // Fetch current author details to retain existing image if not provided
        const [existingAuthor] = await pool.query('SELECT image_name FROM authors WHERE id = ?', [id]);

        if (existingAuthor.length === 0) {
            return res.status(404).json({ success: false, message: 'Author not found' });
        }

        const currentImage = existingAuthor[0].image_name;

        // Use the existing image if a new one isn't provided 
        const newImage = image || currentImage;

        const [result] = await pool.query(
            'UPDATE authors SET name = ?, email = ?, bio = ?, status = ?, image_name = ?, updatedAt = NOW() WHERE id = ?',
            [name, email, bio, status, newImage, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Author not found' });
        }

        res.status(200).json({ success: true, message: 'Author updated' });
    } catch (error) {
        console.error('Error updating author:', error);
        res.status(500).json({ success: false, message: 'Failed to update author' });
    }
}


//delete author API
export async function deleteAuthor(req, res) {
    const { id } = req.body;
    try {
        const pool = getPool();

        const [result] = await pool.query('DELETE FROM authors WHERE id = ?', [id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Author not found' });
        }
        res.status(200).json({ success: true, message: 'Author deleted' });
    } catch (error) {
        console.error('Error deleting author:', error);
        res.status(500).json({ success: false, message: 'Failed to delete author' });
    }
}
