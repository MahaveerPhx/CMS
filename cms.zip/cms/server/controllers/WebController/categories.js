
import { getPool } from "../../config/db.js"


function buildCategoryHierarchy(categories, parentId) {
    const parent = categories.find(category => category.id === parentId);
    const children = categories.filter(
      (category) => category.parentId === parentId
    );

    if (children.length) {
        parent.subCategory = children.map(child => buildCategoryHierarchy(categories, child.id));
    }

    return parent;
}


export async function getCategories(req, res) {
    const { page, limit } = req.body;
    try {
        const pool = getPool();

        let parentCategoriesQuery;
        let params = [];

        if (page && limit) {
            // Calculate offset for pagination
            const offset = (page - 1) * limit;

            // Query to fetch the main categories based on pagination
            parentCategoriesQuery = `
                SELECT id, name, slug ,parentId
                FROM categories
                WHERE parentId IS NULL
                LIMIT ? OFFSET ?;
            `;
            params = [limit, offset];
        } else {
            // Query to fetch all parent categories if no pagination is provided
            parentCategoriesQuery = `
                SELECT id, name, slug ,parentId
                FROM categories
                WHERE parentId IS NULL;
            `;
        }

        // Fetch parent categories
        const [parentCategories] = await pool.query(parentCategoriesQuery, params);

        // If there are no parent categories, return an empty array
        if (parentCategories.length === 0) {
            return res.status(200).json({ success: true, data: [] });
        }

        // Get all categories to build hierarchy
        const allCategoriesQuery = `
            SELECT id, name, slug ,parentId
            FROM categories;
        `;

        const [allCategories] = await pool.query(allCategoriesQuery);

        // Build the nested structure based on parent categories
        const nestedCategories = parentCategories.map(parentCategory => buildCategoryHierarchy(allCategories, parentCategory.id));

        const [columns] = await pool.query('SHOW COLUMNS FROM categories');
        const columnNames = columns.map(column => column.Field);

        res.status(200).json({ success: true, categories: nestedCategories,columnNames });
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch categories' });
    }
}


export async function getOnlyCategories(req, res) {
    const { page, limit, categoryId } = req.body;

    try {
        const pool = getPool();

        let categoriesQuery;
        let params = [];

        if (categoryId) {
            // Fetch a specific category with its subcategories
            categoriesQuery = `
                SELECT id, name, parentId
                FROM categories
                WHERE id = ? OR parentId = ?;
            `;
            params = [categoryId, categoryId];
        } else if (page && limit) {
            // Calculate offset for pagination
            const offset = (page - 1) * limit;

            // Query to fetch the main categories based on pagination
            categoriesQuery = `
                SELECT id, name
                FROM categories
                WHERE parentId IS NULL
                LIMIT ? OFFSET ?;
            `;
            params = [limit, offset];
        } else {
            // Query to fetch all parent categories if no pagination is provided
            categoriesQuery = `
                SELECT id, name
                FROM categories
                WHERE parentId IS NULL;
            `;
        }

        // Fetch categories
        const [categories] = await pool.query(categoriesQuery, params);

        // If no categories are found, return an empty array
        if (categories.length === 0) {
            return res.status(200).json({ success: true, data: [] });
        }

        let result;

        if (categoryId) {
            // Build the nested structure for the specific category and its subcategories
            result = categories.filter(cat => cat.parentId === null).map(parentCategory => buildCategoryHierarchy(categories, parentCategory.id));
        } else {
            result = categories; // Return as-is if only parent categories are requested
        }

        res.status(200).json({ success: true, data: result });
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch categories' });
    }
}


export async function addCategory(req, res) {
    const { name,description = '', parent_category_id = null, status = "active", subCategories = [] } = req.body;

    try {
        const pool = getPool();
        const connection = await pool.getConnection();

        await connection.beginTransaction();

        // Insert the main category
        const [result] = await connection.query(
            `INSERT INTO categories (name, description,status, parent_category_id) VALUES (?, ?, ?, ?)`,
            [name, description, status, parent_category_id]
        );

        const categoryId = result.insertId;

        // Function to insert subcategories recursively
        const insertSubCategories = async (subCategories, parentCategoryId) => {
            for (const subCategory of subCategories) {
                const [subResult] = await connection.query(
                    `INSERT INTO categories (name,description,status, parent_category_id) VALUES (?, ?, ?, ?)`,
                    [subCategory.name, subCategory.description, subCategory.status, parentCategoryId]
                );

                const subCategoryId = subResult.insertId;

                // Recursively insert nested subcategories if any
                if (subCategory.subCategories && subCategory.subCategories.length > 0) {
                    await insertSubCategories(subCategory.subCategories, subCategoryId);
                }
            }
        };

        // Insert subcategories if provided
        if (subCategories.length > 0) {
            await insertSubCategories(subCategories, categoryId);
        }

        await connection.commit();
        connection.release();

        res.status(200).json({ success: true, message: 'Category added successfully' });
    } catch (error) {
        if (connection) {
            await connection.rollback();
            connection.release();
        }
        console.error('Error adding category:', error);
        res.status(500).json({ success: false, message: 'Failed to add category' });
    }
}


export async function updateCategory(req, res) {
    const { id, name,slug, subCategories = [] } = req.body;

    try {
        const pool = getPool();
        const connection = await pool.getConnection();

        await connection.beginTransaction();

        // Update the main category name
        const [result] = await connection.query(
            'UPDATE categories SET name = ?, slug = ? WHERE id = ?',
            [name,slug, id]
        );

        if (result.affectedRows === 0) {
            await connection.rollback();
            connection.release();
            return res.status(404).json({ success: false, message: 'Category not found' });
        }

        // Function to handle subcategory updates or additions
        const updateOrAddSubCategories = async (subCategories, parentId) => {
            for (const subCategory of subCategories) {
                if (subCategory.id) {
                    // Update existing subcategory
                    await connection.query(
                        `UPDATE categories SET name = ?,slug = ? WHERE id = ? AND parentId = ?`,
                        [subCategory.name,subCategory.slug, subCategory.id, parentId]
                    );

                    // Recursively update or add nested subcategories if any
                    if (subCategory.subCategories && subCategory.subCategories.length > 0) {
                        await updateOrAddSubCategories(subCategory.subCategories, subCategory.id);
                    }
                } else {
                    // Insert new subcategory
                    const [subResult] = await connection.query(
                        `INSERT INTO categories (name, slug, parentId) VALUES (?, ?, ?)`,
                        [subCategory.name,subCategory.slug, parentId]
                    );

                    const newSubCategoryId = subResult.insertId;

                    // Recursively insert nested subcategories if any
                    if (subCategory.subCategories && subCategory.subCategories.length > 0) {
                        await updateOrAddSubCategories(subCategory.subCategories, newSubCategoryId);
                    }
                }
            }
        };

        // Call the function to handle subcategories
        if (subCategories.length > 0) {
            await updateOrAddSubCategories(subCategories, id);
        }

    

        await connection.commit();
        connection.release();

        res.status(200).json({ success: true, message: 'Category updated successfully' });
    } catch (error) {
        if (connection) {
            await connection.rollback();
            connection.release();
        }
        console.error('Error updating category:', error);
        res.status(500).json({ success: false, message: 'Failed to update category' });
    }
}


export async function deleteCategory(req, res) {
    const { id } = req.body;

    try {
        const pool = getPool();
        const connection = await pool.getConnection();

        await connection.beginTransaction();

        // Function to recursively delete subcategories
        const deleteSubCategories = async (parentCategoryId) => {
            // Get all subcategories of the given category
            const [subCategories] = await connection.query(
                `SELECT id FROM categories WHERE parent_category_id = ?`,
                [parentCategoryId]
            );

            for (const subCategory of subCategories) {
                // Recursively delete subcategories of the current subcategory
                await deleteSubCategories(subCategory.id);
            }

            // Delete the category itself
            await connection.query(
                `DELETE FROM categories WHERE id = ?`,
                [parentCategoryId]
            );
        };

        // Start the deletion process with the main category
        await deleteSubCategories(id);

        await connection.commit();
        connection.release();

        res.status(200).json({ success: true, message: 'Category and its subcategories deleted successfully' });
    } catch (error) {
        if (connection) {
            await connection.rollback();
            connection.release();
        }
        console.error('Error deleting category:', error);
        res.status(500).json({ success: false, message: 'Failed to delete category' });
    }
}