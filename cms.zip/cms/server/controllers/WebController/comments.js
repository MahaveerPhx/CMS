import { getPool } from "../../config/db.js";

//comments api
export async function getComments(req, res) {
  const { page = 1, limit = 10, articleId = 0 } = req.body;
  const offset = (page - 1) * limit;

  try {
    const pool = getPool();
    let query;
    let queryParams;

    if (articleId === 0) {
      // Query to fetch all comments with userName and articleTitle
      query = `
        SELECT 
          comments.*, 
          CONCAT(users.FirstName, ' ', users.LastName) AS userName, 
          articles.title AS articleTitle
        FROM comments
        JOIN users ON comments.userId = users.id
        JOIN articles ON comments.articleId = articles.id
        LIMIT ?, ?
      `;
      queryParams = [offset, parseInt(limit)];
    } else {
      // Query to fetch comments for a specific articleId with userName and articleTitle
      query = `
        SELECT 
          comments.*, 
          CONCAT(users.FirstName, ' ', users.LastName) AS userName, 
          articles.title AS articleTitle
        FROM comments
        JOIN users ON comments.userId = users.id
        JOIN articles ON comments.articleId = articles.id
        WHERE comments.articleId = ?
        LIMIT ?, ?
      `;
      queryParams = [articleId, offset, parseInt(limit)];
    }

    // Fetch comments
    const [comments] = await pool.query(query, queryParams);

    // Fetch total number of comments
    const countQuery =
      articleId === 0
        ? "SELECT COUNT(*) as totalItems FROM comments"
        : "SELECT COUNT(*) as totalItems FROM comments WHERE articleId = ?";

    const [totalItemsResult] = await pool.query(countQuery, [articleId]);
    const totalItems = totalItemsResult[0].totalItems;

    res.status(200).json({
      success: true,
      comments,
      totalItems,
      currentPage: page,
      totalPages: Math.ceil(totalItems / limit),
    });
  } catch (error) {
    console.error("Error fetching comments:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch comments" });
  }
}

export async function deleteComment(req, res) {
  const { id } = req.body; // Get id from req.body

  try {
    const pool = getPool();
    // Ensure id is provided
    if (!id) {
      return res
        .status(400)
        .json({ success: false, message: "Comment ID is required" });
    }

    // Delete comment from the database
    const [result] = await pool.query("DELETE FROM comments WHERE id = ?", [
      id,
    ]);

    // Check if the comment was found and deleted 
    if (result.affectedRows === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Comment not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "Comment deleted successfully" });
  } catch (error) {
    console.error("Error deleting comment:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to delete comment" });
  }
}
