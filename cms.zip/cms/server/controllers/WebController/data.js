import { getPool } from "../../config/db.js"


export async function getData(req, res) {
    try {
        const pool = getPool();

        const [articlesCount] = await pool.query('SELECT COUNT(*) AS count FROM articles');
        const [authorsCount] = await pool.query('SELECT COUNT(*) AS count FROM authors');
        const [commentsCount] = await pool.query('SELECT COUNT(*) AS count FROM comments');
        const [usersCount] = await pool.query('SELECT COUNT(*) AS count FROM users');

        const data = {
            articlesCount: articlesCount[0].count,
            authorsCount: authorsCount[0].count,
            commentsCount: commentsCount[0].count,
            usersCount: usersCount[0].count
        };


        res.status(200).json({ success: true, data });
    } catch (error) {
        console.error('Error fetching data:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch data' });
    }
}
