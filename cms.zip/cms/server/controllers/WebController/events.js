import { getPool } from "../../config/db.js"



//events api
export async function getEvents(req, res) {
  const { page = 1, limit = 10 } = req.body;

  try {
    const pool = getPool();
    const offset = (page - 1) * limit;

    // Query to fetch events with pagination
    const query = 'SELECT * FROM events LIMIT ?, ?';
    const queryParams = [offset, parseInt(limit)];

    // Query to get the total number of events
    const countQuery = 'SELECT COUNT(*) as totalItems FROM events';

    // Fetch events
    const [events] = await pool.query(query, queryParams);

    // Fetch total number of events
    const [totalItemsResult] = await pool.query(countQuery);
    const totalItems = totalItemsResult[0].totalItems;

    res.status(200).json({
      success: true,
      events,
      totalItems,
      currentPage: page,
      totalPages: Math.ceil(totalItems / limit)
    });
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch events' });
  }
}


export async function deleteEvent(req, res) {
  const { id } = req.body;

  try {
    const pool = getPool();
    // Ensure id is provided
    if (!id) {
      return res.status(400).json({ success: false, message: 'Event ID is required' });
    }

    // Query to delete the event
    const query = 'DELETE FROM events WHERE id = ?';
    const [result] = await pool.query(query, [id]);

    // Check if any row was affected
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    res.status(200).json({ success: true, message: 'Event deleted successfully' });
  } catch (error) {
    console.error('Error deleting event:', error);
    res.status(500).json({ success: false, message: 'Failed to delete event' });
  }
}
