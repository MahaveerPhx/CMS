import { getPool } from "../../config/db.js"
import multiparty from "multiparty";
import fs from "fs";
import path from "path";


// export async function getFiles(req, res) {
//     const { page = 1, limit = 10 } = req.query;
//     try {
//         const pool = getPool();

//         const offset = (page - 1) * limit;
//         const [files] = await pool.query('SELECT * FROM medialibrary LIMIT ?, ?', [offset, parseInt(limit)]);
//         const [totalItemsResult] = await pool.query('SELECT COUNT(*) as totalItems FROM medialibrary');
//         const totalItems = totalItemsResult[0].totalItems;
//         res.status(200).json({ success: true, files, totalItems });
//     } catch (error) {
//         console.error('Error fetching medialibrary:', error);
//         res.status(500).json({ success: false, message: 'Failed to fetch medialibrary' });
//     }
// }


export async function getFiles(req, res) {
    const { page = 1, limit = 10 } = req.query;
    try {
        const pool = getPool();

        const offset = (page - 1) * limit;
        const [files] = await pool.query('SELECT * FROM medialibrary LIMIT ?, ?', [offset, parseInt(limit)]);
        const [totalItemsResult] = await pool.query('SELECT COUNT(*) as totalItems FROM medialibrary');
        const totalItems = totalItemsResult[0].totalItems;

        // Include full URL for each file
        const baseUrl = `${req.protocol}://${req.get('host')}`;

        // Correct the path to serve files from assets/mediaLibrary directories
        const filesWithUrls = files.map(file => {
            let fileUrl = '';
            if (file.type === 'image') {
                fileUrl = `${baseUrl}/assets/mediaLibrary/Image/${file.file}`;
            } else if (file.type === 'video') {
                fileUrl = `${baseUrl}/assets/mediaLibrary/Video/${file.file}`;
            } else if (file.type === 'audio') {
                fileUrl = `${baseUrl}/assets/mediaLibrary/Audio/${file.file}`;
            }

            return {
                ...file,
                fileUrl // Include the constructed file URL
            };
        });

        res.status(200).json({ success: true, files: filesWithUrls, totalItems });
    } catch (error) {
        console.error('Error fetching medialibrary:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch medialibrary' });
    }
}


// // Get all files with filePath
// export async function getFiles(req, res) {
//     const { page = 1, limit = 10 } = req.query;
//     try {
//         const pool = getPool();

//         const offset = (page - 1) * limit;
//         const [files] = await pool.query('SELECT * FROM medialibrary LIMIT ?, ?', [offset, parseInt(limit)]);
//         const [totalItemsResult] = await pool.query('SELECT COUNT(*) as totalItems FROM medialibrary');
//         const totalItems = totalItemsResult[0].totalItems;

//         // Include full URL for each file
//         const baseUrl = `${req.protocol}://${req.get('host')}`; // Base URL of your server
//         const filesWithUrls = files.map(file => ({
//             ...file,
//             fileUrl: `${baseUrl}/${file.filePath}`
//         }));

//         res.status(200).json({ success: true, files: filesWithUrls, totalItems });
//     } catch (error) {
//         console.error('Error fetching medialibrary:', error);
//         res.status(500).json({ success: false, message: 'Failed to fetch medialibrary' });
//     }
// }


// export async function addFile(req, res) {
//     const { type, fileName } = req.body;
//     try {
//         const pool = getPool();

//         const [result] = await pool.query(
//             'INSERT INTO medialibrary (type, fileName) VALUES (?, ?)',
//             [type, fileName]
//         );
//         res.status(201).json({ success: true, id: result.insertId });
//     } catch (error) {
//         console.error('Error creating medialibrary:', error);
//         res.status(500).json({ success: false, message: 'Failed to create medialibrary' });
//     }
// }

// Add a file with URL/path saving
export async function addFile(req, res) {
    const form = new multiparty.Form();

    // Check if the incoming request has the right content type
    if (!req.is('multipart/form-data')) {
        return res.status(415).json({ error: 'Unsupported Media Type' });
    }

    form.parse(req, async (err, fields, files) => {
        if (err) {
            console.error("Error parsing form data:", err);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        try {
            const type = fields.type[0];
            const uploadDir = type === 'image'
                ? "./assets/mediaLibrary/Image/"
                : type === 'video'
                    ? "./assets/mediaLibrary/Video/"
                    : "./assets/mediaLibrary/Audio/";

            const file = files.file[0];
            const ext = path.extname(file.originalFilename);
            const newFileName = Date.now() + ext;
            const newPath = path.join(uploadDir, newFileName);

            // Ensure the upload directory exists
            fs.mkdirSync(uploadDir, { recursive: true });

            // Save the file
            fs.copyFileSync(file.path, newPath);

            // Save file info in database
            const pool = getPool();
            const [result] = await pool.query(
                'INSERT INTO medialibrary (type, fileName, filePath) VALUES (?, ?, ?)',
                [type, newFileName, newPath]
            );

            res.status(201).json({
                success: true,
                id: result.insertId,
                fileName: newFileName,
                filePath: newPath
            });
        } catch (error) {
            console.error("Error saving file locally:", error);
            res.status(500).json({ error: "Internal Server Error" });
        }
    });
}



export async function updateFile(req, res) {
    const { id, type, fileName } = req.body;
    if (!id) {
        return res.status(400).json({ success: false, message: 'ID is required' });
    }
    try {
        const pool = getPool();

        const [result] = await pool.query(
            'UPDATE medialibrary SET type = ?, fileName = ? WHERE id = ?',
            [type, fileName, id]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'medialibrary not found' });
        }
        res.status(200).json({ success: true, message: 'medialibrary updated' });
    } catch (error) {
        console.error('Error updating medialibrary:', error);
        res.status(500).json({ success: false, message: 'Failed to update medialibrary' });
    }
}


export async function deleteFile(req, res) {
    const { id } = req.body;
    try {
        const pool = getPool();

        const [result] = await pool.query('DELETE FROM medialibrary WHERE id = ?', [id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'medialibrary not found' });
        }
        res.status(200).json({ success: true, message: 'medialibrary deleted' });
    } catch (error) {
        console.error('Error deleting medialibrary:', error);
        res.status(500).json({ success: false, message: 'Failed to delete medialibrary' });
    }
}

export async function uploadFile(req, res) {
    console.log("i am here")
    console.log("req body: ", req.body)
    const form = new multiparty.Form();

    form.parse(req, (err, fields, files) => {
        if (err) {
            console.error("Error parsing form data:", err);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        try {

            const type = fields.type[0];
            const uploadDir = type === 'image' ? "./assets/mediaLibrary/Image/" : type == 'video' ? "./assets/mediaLibrary/Video/" : "./assets/mediaLibrary/Audio/";


            const file = files.file[0];

            const ext = path.extname(file.originalFilename);
            const newFileName = Date.now() + ext;
            const newPath = path.join(uploadDir, newFileName);


            fs.copyFileSync(file.path, newPath);

            return res.json({ fileName: newFileName });
        } catch (error) {
            console.error("Error saving file locally:", error);
            return res.status(500).json({ error: "Internal Server Error" });
        }
    });
}

