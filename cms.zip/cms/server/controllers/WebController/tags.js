import { getPool } from "../../config/db.js";

//tags api
export async function createTag(req, res) {
  const { name } = req.body;
  try {
    const pool = getPool();

    const [result] = await pool.query(
      "INSERT INTO tags (name, createdAt, updatedAt) VALUES (?, NOW(), NOW())",
      [name]
    );
    res.status(201).json({ success: true, id: result.insertId });
  } catch (error) {
    console.error("Error creating tag:", error);
    res.status(500).json({ success: false, message: "Failed to create tag" });
  }
}

export async function getTags(req, res) {
  const { page = 1, limit = 10 } = req.body;
  try {
    const pool = getPool();

    const offset = (page - 1) * limit;
    const [tags] = await pool.query(
      "SELECT * FROM tags ORDER BY id DESC LIMIT ?, ?",
      [offset, parseInt(limit)]
    );
    const [totalItemsResult] = await pool.query(
      "SELECT COUNT(*) as totalItems FROM tags"
    );
    const totalItems = totalItemsResult[0].totalItems;
    res.status(200).json({ success: true, tags, totalItems });
  } catch (error) {
    console.error("Error fetching tags:", error);
    res.status(500).json({ success: false, message: "Failed to fetch tags" });
  }
}

export async function updateTag(req, res) {
  const { id, name } = req.body;
  if (!id) {
    return res.status(400).json({ success: false, message: "ID is required" });
  }
  try {
    const pool = getPool();

    const [result] = await pool.query(
      "UPDATE tags SET name = ?, updatedAt = NOW() WHERE id = ?",
      [name, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: "Tag not found" });
    }
    res.status(200).json({ success: true, message: "Tag updated" });
  } catch (error) {
    console.error("Error updating tag:", error);
    res.status(500).json({ success: false, message: "Failed to update tag" });
  }
}

export async function deleteTag(req, res) {
  const { id } = req.body;
  try {
    const pool = getPool();

    const [result] = await pool.query("DELETE FROM tags WHERE id = ?", [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: "Tag not found" });
    }
    res.status(200).json({ success: true, message: "Tag deleted" });
  } catch (error) {
    console.error("Error deleting tag:", error);
    res.status(500).json({ success: false, message: "Failed to delete tag" });
  }
}
