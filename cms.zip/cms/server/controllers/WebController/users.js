import { getPool } from "../../config/db.js";

export async function getUsers(req, res) {
  const { page = 1, limit = 10 } = req.body;

  try {
    const pool = getPool(); 
    const offset = (page - 1) * limit;

    // Query to fetch column names dynamically
    const columnQuery = `
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_NAME = 'users'
    `;
    const [columnsResult] = await pool.query(columnQuery);
    const columns = columnsResult.map((col) => col.COLUMN_NAME);

    // Fetch users data
    const dataQuery = `
      SELECT ${columns.join(", ")}
      FROM users
      LIMIT ?, ?
    `;
    const queryParams = [offset, parseInt(limit)];
    const [users] = await pool.query(dataQuery, queryParams);

    // Fetch total number of users
    const countQuery = "SELECT COUNT(*) as totalItems FROM users";
    const [totalItemsResult] = await pool.query(countQuery);
    const totalItems = totalItemsResult[0].totalItems;

    res.status(200).json({
      success: true,
      headers: columns,
      users,
      totalItems,
      currentPage: page,
      totalPages: Math.ceil(totalItems / limit),
    });
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ success: false, message: "Failed to fetch users" });
  }
}

export async function updateUser(req, res) {
  try {
    const pool = getPool();
    const {
      id,
      FullName,
      FirstName,
      LastName,
      Email,
      MobileNumber,
      Dob,
      Age,
      Gender,
      Pancard,
      aadharNumber,
      CurrentAddress,
      FatherName,
      MotherName,
      IpAddress,
    } = req.body;

    if (!id) {
      return res
        .status(400)
        .json({ success: false, message: "User ID is required" });
    }

    // Create the query to update the user
    const query = `
    UPDATE users 
    SET 
      FullName = COALESCE(?, FullName), 
      FirstName = COALESCE(?, FirstName), 
      LastName = COALESCE(?, LastName), 
      Email = COALESCE(?, Email), 
      MobileNumber = COALESCE(?, MobileNumber), 
      Dob = COALESCE(?, Dob),
      Age = COALESCE(?, Age),
      Gender = COALESCE(?, Gender),
      Pancard = COALESCE(?, Pancard),
      aadharNumber = COALESCE(?, aadharNumber),
      CurrentAddress = COALESCE(?, CurrentAddress),
      FatherName = COALESCE(?, FatherName),
      MotherName = COALESCE(?, MotherName),
      IpAddress = COALESCE(?, IpAddress)
    WHERE id = ?
  `;

    // Execute the query
    const [result] = await pool.query(query, [
      FullName,
      FirstName,
      LastName,
      Email,
      MobileNumber,
      Dob,
      Age,
      Gender,
      Pancard,
      aadharNumber,
      CurrentAddress,
      FatherName,
      MotherName,
      IpAddress,
      id,
    ]);

    // Check if any row was updated
    if (result.affectedRows === 0) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    // Respond with success message
    res
      .status(200)
      .json({ success: true, message: "User updated successfully" });
  } catch (error) {
    console.error("Error updating user:", error);
    res.status(500).json({ success: false, message: "Failed to update user" });
  }
}

export async function deleteUser(req, res) {
  const { id } = req.body; // or req.params if using URL parameters

  try {
    const pool = getPool();
    // Ensure id is provided
    if (!id) {
      return res
        .status(400)
        .json({ success: false, message: "User ID is required" });
    }

    // Query to delete the user
    const query = "DELETE FROM users WHERE id = ?";
    const [result] = await pool.query(query, [id]);

    // Check if any row was affected
    if (result.affectedRows === 0) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "User deleted successfully" });
  } catch (error) {
    console.error("Error deleting user:", error);
    res.status(500).json({ success: false, message: "Failed to delete user" });
  }
}
