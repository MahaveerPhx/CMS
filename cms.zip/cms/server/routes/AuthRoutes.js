import { Router } from "express";
import { login, switchPanel } from "../controllers/AuthController.js";

const router = Router();

router.post("/login", login);

router.post("/switchPanel", switchPanel);
router.post("/checkUser", login);

export default router;
