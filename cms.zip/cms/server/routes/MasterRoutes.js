import { Router } from "express";

import {
  createAdmin,
  deleteAdmin,
  getAdmins,
  updateAdmin,
} from "../controllers/MasterController/admins.js";
import {
  createWebsite,
  deleteWebsite,
  getAllWebsiteDetails,
  getWebsites,
  updateWebsite,
} from "../controllers/MasterController/websites.js";
import {
  addWebsiteAdmin,
  deleteWebsiteAdmin,
  getWebsiteAdmins,
  updateWebsiteAdmin,
} from "../controllers/MasterController/websiteAdmins.js";
import { getMasterData } from "../controllers/MasterController/data.js";

const router = Router();

//websites routes
router.post("/addWebsite", createWebsite);
router.post("/getWebsites", getWebsites);
router.post("/updateWebsite", updateWebsite);
router.post("/deleteWebsite", deleteWebsite);
router.get("/getAllWebsiteDetails", getAllWebsiteDetails);

//admins routes
router.post("/addAdmin", createAdmin);
router.post("/getAdmins", getAdmins);
router.post("/updateAdmin", updateAdmin);
router.post("/deleteAdmin", deleteAdmin);

//websiteAdmins
router.post("/getWebsiteAdmins", getWebsiteAdmins);
router.post("/addWebsiteAdmin", addWebsiteAdmin);
router.post("/updateWebsiteAdmin", updateWebsiteAdmin);
router.post("/deleteWebsiteAdmin", deleteWebsiteAdmin);

//get master data api
router.post("/getMasterData", getMasterData);

export default router;
