import { uploadImage } from '../controllers/FileUploadController.js'
import { Router } from "express";
const router = Router();

router.post("/", uploadImage);

export default router;