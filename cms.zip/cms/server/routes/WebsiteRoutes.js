import { Router } from "express";
import { createArticle, deleteArticle, getArticles, updateArticle, uploadImage } from "../controllers/WebController/articles.js";
import { createAuthor, deleteAuthor, getAuthors, updateAuthor } from "../controllers/WebController/authors.js";
import { deleteComment, getComments } from "../controllers/WebController/comments.js";
import { deleteUser, getUsers, updateUser } from "../controllers/WebController/users.js";
import { deleteEvent, getEvents } from "../controllers/WebController/events.js";
import { getCategories, getOnlyCategories, addCategory, updateCategory, deleteCategory } from "../controllers/WebController/categories.js";
import { createTag, deleteTag, getTags, updateTag } from "../controllers/WebController/tags.js";
import { getData } from "../controllers/WebController/data.js";
import { createAd, deleteAd, getAds, updateAd } from "../controllers/WebController/ads.js";
import { addFile, deleteFile, getFiles, updateFile, uploadFile } from "../controllers/WebController/mediaLibrary.js";

const router = Router();

//Image Upload-
router.post("/uploadImage", uploadImage);

//articles routes
router.post("/addArticle", createArticle);
router.post("/getArticles", getArticles);
router.post("/updateArticle", updateArticle);
router.post("/deleteArticle", deleteArticle);

//authors api
router.post("/addAuthor", createAuthor);
router.post("/getAuthors", getAuthors);
router.post("/updateAuthor", updateAuthor);
router.post("/deleteAuthor", deleteAuthor);

//comments api
router.post("/getComments", getComments);
router.post("/deleteComment", deleteComment);

//users api
router.post("/getUsers", getUsers);
router.post("/deleteUser", deleteUser);
router.post("/updateUser", updateUser);

//categories api
router.post("/getCategories", getCategories);
router.post("/getOnlyCategories", getOnlyCategories);
router.post("/addCategory", addCategory);
router.post("/updateCategory", updateCategory);
router.post("/deleteCategory", deleteCategory);

//events api
router.post("/getEvents", getEvents);
router.post('/deleteEvent', deleteEvent);

//tags api
router.post("/addTag", createTag);
router.post("/getTags", getTags);
router.post("/updateTag", updateTag);
router.post("/deleteTag", deleteTag);

//ads api
router.post("/addAd", createAd);
router.post("/getAds", getAds);
router.post('/updateAd', updateAd);
router.post("/deleteAd", deleteAd);

//Media Library api 
router.post("/getFiles", getFiles);
router.post("/addFile", addFile);
router.post('/updateFile', updateFile);
router.post("/deleteFile", deleteFile);
router.post("/uploadFile", uploadFile);

//get data 
router.post('/getData', getData);

export default router;