import {
  PresentationChartBarIcon,
  UserCircleIcon,
  InboxIcon,
  GlobeAltIcon,
  UserGroupIcon,
  ClipboardIcon,
  UserIcon,
  PencilSquareIcon,
  ChatBubbleLeftEllipsisIcon,
  ClockIcon,
  TagIcon,
  FunnelIcon,
} from "@heroicons/react/24/solid";

export const masterSideBarList = [
  {
    id: 1,
    // icon: <UserCircleIcon className="h-5 w-5" />,
    icon: <ClipboardIcon className="h-5 w-5" />,
    text: "Dashboard",
    pathName: "/",
  },
  {
    id: 2,
    icon: <GlobeAltIcon className="h-5 w-5" />,
    text: "Manage Websites",
    pathName: "/master/websites",
  },
  {
    id: 3,
    icon: <UserGroupIcon className="h-5 w-5" />,
    text: "Manage Admins",
    pathName: "/master/admins",
  },

  {
    id: 4,
    icon: <PresentationChartBarIcon className="h-5 w-5" />,
    text: "Manage Website Admins",
    pathName: "/master/website-admins",
  },
  {
    id: 5,
    icon: <PresentationChartBarIcon className="h-5 w-5" />,
    text: "Manage Website Genre",
    pathName: "/master/website-genre",
  },
];

export const webSideBarList = [
  {
    id: 0,
    icon: <UserCircleIcon className="h-5 w-5" />,
    icon: <ClipboardIcon className="h-5 w-5" />,
    text: "Dashboard",
    pathName: "/",
  },
  {
    id: 1,
    icon: <GlobeAltIcon className="h-5 w-5" />,
    icon: <PencilSquareIcon className="h-5 w-5" />,
    text: "Articles",
    pathName: "/web/articles",
  },

  {
    id: 2,
    icon: <GlobeAltIcon className="h-5 w-5" />,
    text: "Category",
    pathName: "/web/categories",
  },

  {
    id: 3,
    icon: <GlobeAltIcon className="h-5 w-5" />,
    icon: <UserIcon className="h-5 w-5" />,
    text: "Authors",
    pathName: "/web/authors",
  },

  {
    id: 4,
    icon: <ChatBubbleLeftEllipsisIcon className="h-5 w-5" />,
    text: "Comment",
    pathName: "/web/comments",
  },

  {
    id: 5,
    icon: <UserGroupIcon className="h-5 w-5" />,
    text: "Users",
    pathName: "/web/users",
  },

  {
    id: 6,
    icon: <TagIcon className="h-5 w-5" />,
    text: "Tags",
    pathName: "/web/tags",
  },

  {
    id: 7,
    icon: <FunnelIcon className="h-5 w-5" />,
    text: "Ads",
    pathName: "/web/ads",
  },

  {
    id: 8,
    icon: <FunnelIcon className="h-5 w-5" />,
    text: "Titles",
    pathName: "/web/media-library",
  },
];
