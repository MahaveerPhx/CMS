import React, { useEffect } from 'react'
import SideBar from './SideBar'
import { useSelector } from 'react-redux'
import { useRouter } from 'next/router'

export default function Layout({ children }) {

    const isLogin = useSelector((state)=> state.data.isLogin)
    const router = useRouter()

     useEffect(()=>{
       if (!isLogin) {
          router.push('/Auth/login')
       }
     },[])
    
    return (
        <>
            {isLogin ? <div className="flex max-h-screen overflow-hidden">

                <SideBar />

                <div className={`overflow-y-scroll  scroll-smooth scrollbar-thin scrollbar-thumb-primary-color scrollbar-track-white scrollbar-thumb-rounded-full w-[calc(100%)]`}>
                    {/* <Navbar /> */}
                    <div className="px-4 md:px-4"> {children}</div>
                </div>
            </div> : <div className="px-4 md:px-4"> {children}</div>}

        </>
    )
}
