import { useCallback, useEffect, useState } from "react";
import {
  Button,
  Input,
  Dialog,
  DialogFooter,
  DialogHeader,
  DialogBody,
  Checkbox,
} from "@material-tailwind/react";
import { useGetAllWebsiteDetailsQuery } from "@/globalStates/masterApiSlice";
import { Select, Option } from "@material-tailwind/react";
import Multiselect from "multiselect-react-dropdown";

export default function AddAdmin({
  open,
  setOpen,
  handleAdd,
  currentData,
  setCurrentData,
}) {
  const roles = ["admin", "editor", "viewer"];
  const { data = {}, error, isLoading } = useGetAllWebsiteDetailsQuery();
  const [selectedWebsiteNamesOptions, setSelectedWebsiteNamesOptions] =
    useState([]);
  const handleWebsiteNameSelect = (selectedBrowseList) => {
    setSelectedWebsiteNamesOptions(selectedBrowseList);
    const selectedBrowseIds = selectedBrowseList.map((list) => list.id);
    const browseIdsString = selectedBrowseIds.join(",");
  };
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    articleId: "",
    role: "",
  });

  useEffect(() => {
    if (currentData) {
      setFormData({
        id: currentData.id,
        name: currentData.name,
        email: currentData.email,
        password: currentData.password,
        role: currentData.role,
      });
    }
  }, [currentData]);

  const handleOpen = () => {
    setOpen(!open);
    setFormData({
      name: "",
      email: "",
      password: "",
      role: "",
      articleId: "",
    });

    setCurrentData(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = () => {
    handleAdd(formData);
    handleOpen();
  };
  const options =
    data.websiteAllDetails &&
    data.websiteAllDetails.map((websiteDetails) => ({
      name: websiteDetails.name, // The value to be shown in the dropdown
      id: websiteDetails.id, // You can use this as the key if necessary
    }));
  return (
    <>
      <Button onClick={handleOpen} variant="gradient">
        Add Admin
      </Button>

      <Dialog open={open} size="lg" handler={handleOpen}>
        <DialogHeader>
          <div>{currentData ? "Edit Admin" : "Add Admin"}</div>
        </DialogHeader>

        <DialogBody>
          <div className="flex flex-wrap gap-5">
            <div className="w-[48%]">
              <Input
                name="name"
                label="Name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div className="w-[48%]">
              <Input
                name="email"
                label="Email"
                value={formData.email}
                onChange={handleChange}
              />
            </div>

            <div className="w-[48%]">
              <Input
                name="password"
                label="Password"
                value={formData.password}
                onChange={handleChange}
              />
            </div>

            <div className="w-[48%]">
              <Select
                label="Select Role"
                value={formData.role}
                onChange={(value) => setFormData({ ...formData, role: value })}
              >
                {roles.map((role) => (
                  <Option value={role} key={role}>
                    {role}
                  </Option>
                ))}
              </Select>
            </div>

            <div className="w-[48%]">
              <Multiselect
                options={options}
                selectedValues={selectedWebsiteNamesOptions}
                onSelect={handleWebsiteNameSelect}
                onRemove={handleWebsiteNameSelect}
                displayValue="name"
                placeholder={
                  selectedWebsiteNamesOptions.length === 0
                    ? "Select Websites"
                    : ""
                }
              />
              <div className="mt-2">
                <input
                  id="select-all-checkbox"
                  type="checkbox"
                  value=""
                  className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                  // onChange={handleSelectAll}
                />
                <label
                  htmlFor="select-all-checkbox"
                  className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
                >
                  All
                </label>
              </div>
            </div>
          </div>
        </DialogBody>

        <DialogFooter>
          <div className="mt-4">
            <Button
              variant="text"
              color="red"
              onClick={handleOpen}
              className="mr-1"
            >
              <span>Cancel</span>
            </Button>
            <Button variant="gradient" color="green" onClick={handleSubmit}>
              <span>{currentData ? "Update Admin" : "Add Admin"}</span>
            </Button>
          </div>
        </DialogFooter>
      </Dialog>
    </>
  );
}
