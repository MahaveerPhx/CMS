import { useCallback, useEffect, useState } from "react";
import {
  Button,
  Input,
  Dialog,
  DialogFooter,
  DialogHeader,
  DialogBody,
} from "@material-tailwind/react";
import { Select, Option } from "@material-tailwind/react";
import {
  useGetAdminsMutation,
  useGetWebsitesMutation,
} from "@/globalStates/masterApiSlice";

export default function AddWebsiteAdmin({
  open,
  setOpen,
  handleAdd,
  currentData,
  setCurrentData,
}) {
  const roles = ["admin", "editor", "viewer"];
  const [getAdmins, { data: admins }] = useGetAdminsMutation();
  const [getWebsites, { data: websites }] = useGetWebsitesMutation();

  const fetchData = useCallback(async () => {
    await getWebsites({ page: 1, limit: 10 });
    await getAdmins({ page: 1, limit: 10 });
  }, []); // Empty dependency array to make fetchData stable

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const [formData, setFormData] = useState({
    websiteId: "",
    adminId: "",
    role: "",
  });

  useEffect(() => {
    if (currentData) {
      setFormData({
        id: currentData.id,
        websiteId: currentData.websiteId,
        adminId: currentData.adminId,
        role: currentData.role,
      });
    }
  }, [currentData]);

  const handleOpen = () => {
    setOpen(!open);
    setFormData({
      websiteId: "",
      adminId: "",
      role: "",
    });

    setCurrentData(null);
  };

  const handleSubmit = () => {
    handleAdd(formData);
    handleOpen();
  };

  return (
    <>
      <Button onClick={handleOpen} variant="gradient">
        Add WebAdmin
      </Button>

      <Dialog open={open} size="lg" handler={handleOpen}>
        <DialogHeader>
          <div>{currentData ? "Edit WebAdmin" : "Add WebAdmin"}</div>
        </DialogHeader>

        <DialogBody>
          <div className="flex flex-wrap gap-5">
            {websites && (
              <div className="w-[48%]">
                <Select
                  label="Select Webiste"
                  value={formData.websiteId}
                  onChange={(value) =>
                    setFormData({ ...formData, websiteId: value })
                  }
                >
                  {websites.websites.map((web) => (
                    <Option value={web.id} key={web.id}>
                      {web.name}
                    </Option>
                  ))}
                </Select>
              </div>
            )}

            {admins && (
              <div className="w-[48%]">
                <Select
                  label="Select Admin"
                  value={formData.adminId}
                  onChange={(value) =>
                    setFormData({ ...formData, adminId: value })
                  }
                >
                  {admins.admins.map((ad) => (
                    <Option value={ad.id} key={ad.id}>
                      {ad.name}
                    </Option>
                  ))}
                </Select>
              </div>
            )}

            <div className="w-[48%]">
              <Select
                label="Select Role"
                value={formData.role}
                onChange={(value) => setFormData({ ...formData, role: value })}
              >
                {roles.map((role) => (
                  <Option value={role} key={role}>
                    {role}
                  </Option>
                ))}
              </Select>
            </div>
          </div>
        </DialogBody>

        <DialogFooter>
          <div className="mt-4">
            <Button
              variant="text"
              color="red"
              onClick={handleOpen}
              className="mr-1"
            >
              <span>Cancel</span>
            </Button>
            <Button variant="gradient" color="green" onClick={handleSubmit}>
              <span>{currentData ? "Update WebAdmin" : "Add WebAdmin"}</span>
            </Button>
          </div>
        </DialogFooter>
      </Dialog>
    </>
  );
}
