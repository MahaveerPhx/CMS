
import { useEffect, useState } from 'react'
import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';


export default function AddWebsite({ open, setOpen, handleAdd, currentData, setCurrentData }) {

    const [formData, setFormData] = useState({
        name: '',
        domain: '',
        host: '',
        user: '',
        password: '',
        databaseName: ''
    });


    useEffect(() => {
        if (currentData) {
            setFormData({
                id: currentData.id,
                name: currentData.name,
                domain: currentData.domain,
                host: currentData.host,
                user: currentData.user,
                password: currentData.password,
                databaseName: currentData.databaseName

            });
        }
    }, [currentData]);

    const handleOpen = () => {
        setOpen(!open);
        setFormData({
            name: '',
            domain: '',
            host: '',
            user: '',
            password: '',
            databaseName: ''
        });

        setCurrentData(null)

    };


    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = () => {
        handleAdd(formData);
        handleOpen();
    };


    return (
        <>
            <Button onClick={handleOpen} variant="gradient">
                Add Website
            </Button>

            <Dialog open={open} size="lg" handler={handleOpen}>


                <DialogHeader >
                    <div>
                        {currentData ? "Edit Website" : "Add Website"}
                    </div>
                </DialogHeader>

                <DialogBody >
                    <div className="flex flex-wrap gap-5" >


                        <div className="w-[48%]">

                            <Input
                                name="name"
                                label="Name"
                                value={formData.name}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">

                            <Input
                                name="domain"
                                label="Domain"
                                value={formData.domain}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">

                            <Input
                                name="host"
                                label="Host"
                                value={formData.host}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="user"
                                label="User"
                                value={formData.user}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="password"
                                label="Password"
                                value={formData.password}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="databaseName"
                                label="Database Name"
                                value={formData.databaseName}
                                onChange={handleChange}
                            />
                        </div>


                    </div>
                </DialogBody>

                <DialogFooter>

                    <div className="mt-4">
                        <Button
                            variant="text"
                            color="red"
                            onClick={handleOpen}
                            className="mr-1"
                        >
                            <span>Cancel</span>
                        </Button>
                        <Button variant="gradient" color="green" onClick={handleSubmit}>
                            <span>{currentData ? "Update Website" : "Add Website"}</span>
                        </Button>
                    </div>
                </DialogFooter>


            </Dialog>
        </>
    )
}