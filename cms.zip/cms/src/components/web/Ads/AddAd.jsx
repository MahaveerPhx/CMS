
// import { useEffect, useState } from "react";
// import { PencilIcon, MagnifyingGlassIcon, TrashIcon } from "@heroicons/react/24/solid";
// import { Card, Typography, Button, CardBody, CardFooter, IconButton, Tooltip, Input } from "@material-tailwind/react";
// import { useAddAdsMutation, useDeleteAdsMutation, useGetAdsMutation, useUpdateAdsMutation } from "@/globalStates/webApiSlice";
// import AddAd from "@/components/web/Ads/AddAd";

// export default function Ads() {
//     const TABLE_HEAD = ["id", "title", "description", "type", "start_date", "end_date", "Status", "ads_size", "image_path", "code", "ad_url", "ad_page", "ad_section","Action"];
//     const [currentData, setCurrentData] = useState(null);
//     const [getAds, { data, error, isLoading }] = useGetAdsMutation();
//     const [addAds] = useAddAdsMutation();
//     const [updateAds] = useUpdateAdsMutation();
//     const [deleteAds] = useDeleteAdsMutation();

//     const [open, setOpen] = useState(false);
//     const [searchQuery, setSearchQuery] = useState("");

//     const fetchData = async () => {
//         await getAds({ page: 1, limit: 10 });
//     };

//     useEffect(() => {
//         fetchData();
//     }, []);

//     const handleAdd = async (data) => {
//         try {
//             if (currentData) {
//                 await updateAds({ ...data, id: currentData.id }).unwrap();
//             } else {
//                 await addAds(data).unwrap();
//             }
//             setOpen(false);
//             fetchData();
//             setCurrentData(null);
//         } catch (error) {
//             console.error("Failed to add/update ad:", error);
//         }
//     };

//     const handleEdit = (ad) => {
//         setCurrentData(ad);
//         setOpen(true);
//     };

//     async function handleDelete(id) {
//         await deleteAds(id);
//         fetchData();
//     }

//     const filteredAds = data?.ads?.filter((ad) =>
//         ad.title.toLowerCase().includes(searchQuery.toLowerCase())
//     );
//     console.log(filteredAds);
//     return (
//         <Card className="h-full w-full">
//             <div className="rounded-none p-5">
//                 <div className="mb-4 flex flex-col justify-between gap-8 md:flex-row md:items-center">
//                     <div>
//                         <Typography variant="h5" color="blue-gray">
//                             Ads List
//                         </Typography>
//                     </div>
//                     <div className="flex w-full shrink-0 gap-2 md:w-max">
//                         <div className="w-full md:w-72">
//                             <Input
//                                 label="Search"
//                                 icon={<MagnifyingGlassIcon className="h-5 w-5" />}
//                                 value={searchQuery}
//                                 onChange={(e) => setSearchQuery(e.target.value)}
//                             />
//                         </div>
//                         <AddAd open={open} setOpen={setOpen} handleAdd={handleAdd} currentData={currentData} setCurrentData={setCurrentData} />
//                     </div>
//                 </div>
//             </div>

//             <CardBody className="overflow-scroll px-0">
//                 <table className="w-full min-w-max table-auto text-left">
//                     <thead>
//                         <tr>
//                             {TABLE_HEAD.map((head) => (
//                                 <th key={head} className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4">
//                                     <Typography variant="small" color="blue-gray" className="font-normal leading-none opacity-70">
//                                         {head}
//                                     </Typography>
//                                 </th>
//                             ))}
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {filteredAds?.map(({ id, title, description, type, start_date, end_date, status, ads_size, image_path, code, ad_url, ad_page, ad_section }, index) => {
//                             const isLast = index === filteredAds.length - 1;
//                             const classes = isLast ? "p-4" : "p-4 border-b border-blue-gray-50";

//                             return (
//                                 <tr key={index}>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {id}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {title}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {description}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {type}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {start_date}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {end_date}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {status}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {ads_size}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {image_path}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {code}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {ad_url}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {ad_page}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <Typography variant="small" color="blue-gray" className="">
//                                             {ad_section}
//                                         </Typography>
//                                     </td>
//                                     <td className={classes}>
//                                         <div className="flex gap-2">
//                                             <Tooltip content="Edit Ad">
//                                                 <IconButton
//                                                     variant="text"
//                                                     color="blue-gray"
//                                                     onClick={() => handleEdit({
//                                                         id, title, description, type, start_date, end_date, status,
//                                                         ads_size, image_path, code, ad_url, ad_page, ad_section
//                                                     })}>
//                                                     <PencilIcon className="h-5 w-5" />
//                                                 </IconButton>

//                                             </Tooltip>
//                                             <Tooltip content="Delete Ad">
//                                                 <IconButton variant="text" color="blue-gray" onClick={() => handleDelete(id)}>
//                                                     <TrashIcon className="h-5 w-5" />
//                                                 </IconButton>
//                                             </Tooltip>
//                                         </div>
//                                     </td>
//                                 </tr>
//                             );
//                         })}
//                     </tbody>
//                 </table>
//             </CardBody>
//         </Card>
//     );
// }


import { useEffect, useState } from 'react';
import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';
import { Select, Option } from '@material-tailwind/react';

export default function AddAd({ open, setOpen, handleAdd, currentData, setCurrentData }) {
    const [formData, setFormData] = useState({
        id: '',
        title: '',
        description: '',
        type: '',
        startDate: '',
        endDate: '',
        status: '',
        adsSize: '', // Added field
        imagePath: '', // Added field
        code: '', // Added field
        adUrl: '', // Added field
        adPage: '', // Added field
        adSection: '' // Added field
    });

    useEffect(() => {
        if (currentData) {
            const formatDate = (dateString) => {
                const date = new Date(dateString);
            
                // Check if the date is valid
                if (isNaN(date.getTime())) {
                    return '';  // Return an empty string or some default value if the date is invalid
                }
                return date.toISOString().split('T')[0];
            };
            
            setFormData({
                id: currentData.id || '',
                title: currentData.title || '',
                description: currentData.description || '',
                type: currentData.type || '',
                startDate: formatDate(currentData.start_date),
                endDate: formatDate(currentData.end_date),
                status: currentData.status || '',
                adsSize: currentData.ads_size || '',  // Default if data not available
                imagePath: currentData.image_path || '',
                code: currentData.code || '',
                adUrl: currentData.ad_url || '',
                adPage: currentData.ad_page || '',
                adSection: currentData.ad_section || ''
            });
        }
    }, [currentData]);

    const handleOpen = () => {
        setOpen(!open);
        setFormData({
            id: '',
            title: '',
            description: '',
            type: '',
            startDate: '',
            endDate: '',
            status: '',
            adsSize: '', 
            imagePath: '', 
            code: '', 
            adUrl: '', 
            adPage: '', 
            adSection: '' 
        });
        setCurrentData(null);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = () => {
        handleAdd(formData);
        handleOpen();
    };

    const handleOptionChange = (value) => {
        setFormData({ ...formData, status: value });
    };

    return (
        <>
            <Button onClick={handleOpen} variant="gradient">
                {currentData ? "Edit Ad" : "Add Ad"}
            </Button>

            <Dialog open={open} size="lg" handler={handleOpen}>
                <DialogHeader >
                    <div>
                        {currentData ? "Edit Ad" : "Add Ad"}
                    </div>
                </DialogHeader>

                <DialogBody >
                    <div className="flex flex-wrap gap-5">
                        <div className="w-[48%]">
                            <Input
                                name="title"
                                label="Title"
                                value={formData.title}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="description"
                                label="Description"
                                value={formData.description}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="type"
                                label="Type"
                                value={formData.type}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                type="date"
                                name="startDate"
                                label="Start Date"
                                value={formData.startDate}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                type="date"
                                name="endDate"
                                label="End Date"
                                value={formData.endDate}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="adsSize"
                                label="Ad Size"
                                value={formData.adsSize}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="imagePath"
                                label="Image Path"
                                value={formData.imagePath}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="code"
                                label="Code"
                                value={formData.code}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="adUrl"
                                label="Ad URL"
                                value={formData.adUrl}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="adPage"
                                label="Ad Page"
                                value={formData.adPage}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Input
                                name="adSection"
                                label="Ad Section"
                                value={formData.adSection}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="w-[48%]">
                            <Select label="Status" className="w-full" name="status" value={formData.status} onChange={handleOptionChange}>
                                <Option value="active">Active</Option>
                                <Option value="inactive">Inactive</Option>
                            </Select>
                        </div>

                    </div>
                </DialogBody>

                <DialogFooter>
                    <div className="mt-4">
                        <Button
                            variant="text"
                            color="red"
                            onClick={handleOpen}
                            className="mr-1"
                        >
                            <span>Cancel</span>
                        </Button>
                        <Button variant="gradient" color="green" onClick={handleSubmit}>
                            <span>{currentData ? "Update Ad" : "Add Ad"}</span>
                        </Button>
                    </div>
                </DialogFooter>
            </Dialog>
        </>
    );
}
