import React, { useEffect, useState,useCallback} from 'react';
import dynamic from 'next/dynamic'

import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';
import { Select, Option } from "@material-tailwind/react";
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
// import ImageResize from '@ckeditor/ckeditor5-image/src/imageresize';
// import ImageStyle from '@ckeditor/ckeditor5-image/src/imagestyle';

import { UPLOAD_IMAGE_ROUTE } from '@/utils/ApiRoutes';
import { useGetAuthorsMutation, useGetCatgoriesMutation } from '@/globalStates/webApiSlice';


export default function AddArticle({ open, setOpen, handleAdd, currentData, setCurrentData }) {

    const status = ['draft', 'published'];
    const [getAuthors, { data: authorsData }] = useGetAuthorsMutation();
    const [getCategories, { data: categoriesData }] = useGetCatgoriesMutation();

    const [formData, setFormData] = useState({
        id: '',
        title: '',
        authorId: '',
        categoryId: '',
        content: '',
        status: '',
        createdBy: '',
        updatedBy: '',
        scheduleStartTime: '',
        scheduleEndTime: '',
    });

    console.log("formData", formData);

    const [selectedCategories, setSelectedCategories] = useState([]);


    const fetchData = useCallback(async () => {
        await getAuthors({ page: 1, limit: 10 });
        await getCategories();
    }, []); // Empty dependency array makes fetchData stable

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    console.log("categoriesData", categoriesData)

    useEffect(() => {
        if (currentData) {
            console.log("currentData", currentData)
            setFormData({
                id: currentData.id,
                title: currentData.title,
                authorId: currentData.authorId,
                categoryId: currentData.categoryId,
                content: currentData.content,
                status: currentData.status,
                scheduleStartTime: currentData.scheduleStartTime,
                scheduleEndTime: currentData.scheduleEndTime,
                createdBy: currentData.createdBy,
                updatedBy: currentData.updatedBy
            });    

            // Pre-select the category and its hierarchy based on currentData.categoryId
            const selectedHierarchy = buildSelectedHierarchy(currentData.categoryId, categoriesData?.categories);
            setSelectedCategories(selectedHierarchy);
        }
    }, [currentData, categoriesData]);

    const handleOpen = () => {
        setOpen(!open);
        setFormData({
            title: '',
            authorId: '',
            categoryId: '',
            content: '',
            status: '',
            image: '',
            scheduleStartTime: '',
            scheduleEndTime: '',
        });
        setSelectedCategories([]);
        setCurrentData(null);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = () => {
        handleAdd(formData);
        handleOpen();
    };

    const handleEditorChange = (event, editor) => {
        const data = editor.getData();
        setFormData((prevFormData) => ({
            ...prevFormData, // Preserve the existing state
            content: data,   // Update only the content field
        }));
    };

    const handleCategoryChange = (value, level) => {
        const updatedCategories = [...selectedCategories.slice(0, level), value];

        const selectedCategory = findCategoryById(value, categoriesData?.categories);
        const subCategories = selectedCategory?.subCategory || [];

        if (subCategories.length === 0) {
            setFormData({ ...formData, categoryId: value });
        } else {
            setFormData({ ...formData, categoryId: value });
        }

        setSelectedCategories(updatedCategories);
    };

    const buildSelectedHierarchy = (categoryId, categories) => {
        const hierarchy = [];
        let currentCategory = findCategoryById(categoryId, categories);

        // Traverse up the hierarchy by finding each parent category
        while (currentCategory) {
            hierarchy.unshift(currentCategory.id); // Add the current category to the beginning of the hierarchy array
            currentCategory = findCategoryById(currentCategory.parent_category_id, categories); // Move to the parent category
        }
        return hierarchy;
    };

    const findCategoryById = (id, categories) => {
        for (const category of categories) {
            if (category.id === id) return category;
            // Check if there is a match within subcategories recursively
            if (category.subCategory && category.subCategory.length > 0) {
                const foundCategory = findCategoryById(id, category.subCategory);
                if (foundCategory) return foundCategory;
            }
        }
        return null;
    };

    const renderCategorySelects = () => {
        const selects = [];
        let subCategories = categoriesData?.categories.filter(category => category.parent_category_id === null);
        selectedCategories.forEach((selectedCategoryId, index) => {

            selects.push(
                <div key={index} className="w-[48%]">
                    {subCategories && subCategories.length > 0 && <Select
                        label={`Select ${index == 0 ? 'Category' : 'Subcategory optional'}`}
                        value={selectedCategoryId}
                        onChange={(value) => handleCategoryChange(value, index)}
                    >
                        {subCategories?.map((category) => (
                            <Option key={category.id} value={category.id}>
                                {category.name}
                            </Option>
                        ))}
                    </Select>}
                </div>
            );

            const selectedCategory = findCategoryById(selectedCategoryId, subCategories);
            subCategories = selectedCategory?.subCategory || [];
        });

        if (subCategories?.length > 0) {
            selects.push(
                <div key={selectedCategories.length} className="w-[48%]">
                    <Select
                        label={`Select Category`}
                        value=""
                        onChange={(value) => handleCategoryChange(value, selectedCategories.length)}
                    >
                        {subCategories.map((category) => (
                            <Option key={category.id} value={category.id}>
                                {category.name}
                            </Option>
                        ))}
                    </Select>
                </div>
            );
        }

        return selects;
    };

    console.log("formdata: ",formData.content)

    return (
        <>
            <Button onClick={handleOpen} variant="gradient">
                Add Article
            </Button>

            <Dialog open={open} size="xxl" handler={handleOpen}>
                <div className='container mx-auto'>
                    <DialogHeader>
                        <div>
                            {currentData ? "Edit Article" : "Add Article"}
                        </div>
                    </DialogHeader>

                    <DialogBody>
                        <div className="flex flex-wrap gap-5 mx-auto">
                            <div className="w-[48%]">
                                <Input
                                    name="title"
                                    label="Title"
                                    value={formData.title}
                                    onChange={handleChange}
                                />
                            </div>

                            {
                                currentData && (
                                     <div className="w-[48%]">
                                        <Input
                                          name="createdBy"
                                          label="Created By"
                                          value={formData.createdBy}
                                          onChange={handleChange}
                                        />
                                    </div>
                                )
                            }

                            <div className="w-[48%]">
                                <Input
                                    type="datetime-local"
                                    name="scheduleStartTime"
                                    label="Schedule Start Time"
                                    value={formData.scheduleStartTime.split(':00.000Z')[0]} // Ensure proper format for datetime-local
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="w-[48%]">
                                <Input
                                    type="datetime-local"
                                    name="scheduleEndTime"
                                    label="Schedule End Time"
                                    value={formData.scheduleEndTime.split(':00.000Z')[0]} // Ensure proper format for datetime-local
                                    onChange={handleChange}
                                />
                            </div>


                            <div className="w-[48%]">
                                <Select label="Select Author" value={formData.authorId} onChange={(value) => setFormData({ ...formData, authorId: value })}>
                                    {authorsData?.authors.map((author) => (
                                        <Option key={author.id} value={author.id}>{author.name}</Option>
                                    ))}
                                </Select>
                            </div>

                            <div className="w-[48%]">
                                <Select label="Select Status" value={formData.status} onChange={(value) => setFormData({ ...formData, status: value })}>
                                    {status.map((s) => (
                                        <Option key={s} value={s}>{s}</Option>
                                    ))}
                                </Select>
                            </div>

                            {renderCategorySelects()}

                            <div className="w-[97%]">                                    
                                <CKEditor
                                    editor={ClassicEditor}
                                    data="Hello from CKEditor 5!"
                                    onChange={handleEditorChange}
                                    config={{
                                    ckfinder: {
                                      uploadUrl: UPLOAD_IMAGE_ROUTE,
                                    },
                                    toolbar: [
                                      'heading', '|', 'bold', 'italic', 'link', '|',
                                      'imageUpload', 'blockQuote', '|', 'undo', 'redo',
                                    ],
                                    image: {
                                      toolbar: [
                                        'imageStyle:full',
                                        'imageStyle:side',
                                        '|',
                                        'imageTextAlternative',
                                      ],
                                      resizeOptions: [
                                        {
                                          name: 'resizeImage:original',
                                          label: 'Original',
                                          value: null,
                                        },
                                        {
                                          name: 'resizeImage:50',
                                          label: '50%',
                                          value: '50',
                                        },
                                        {
                                          name: 'resizeImage:75',
                                          label: '75%',
                                          value: '75',
                                        },
                                      ],
                                    },
                                    // extraPlugins: [
                                    //   ImageResize,  // Ensures image resizing functionality
                                    //   ImageStyle    // Ensures image positioning options
                                    // ],
                                  }}
                                />
                                
                            </div>
                        </div>
                    </DialogBody>

                    <DialogFooter>
                        <div className="mt-4">
                            <Button
                                variant="text"
                                color="red"
                                onClick={handleOpen}
                                className="mr-1"
                            >
                                <span>Cancel</span>
                            </Button>
                            <Button variant="gradient" color="green" onClick={handleSubmit}>
                                <span>{currentData ? "Update Article" : "Add Article"}</span>
                            </Button>
                        </div>
                    </DialogFooter>
                </div>
            </Dialog>
        </>
    );
}
