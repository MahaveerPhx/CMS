import { UPLOAD_IMAGE_ROUTE } from "@/utils/ApiRoutes";

export default function MyCustomUploadAdapterPlugin(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
        return new MyCustomUploadAdapter(loader);
    };
}

class MyCustomUploadAdapter {

    constructor(loader) {
        this.loader = loader;
    }

    async upload() {
        const file = await this.loader.file;
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(UPLOAD_IMAGE_ROUTE, {  // Replace with your actual API endpoint
            method: 'POST',
            body: formData,
        });

        const responseData = await response.json();

        if (responseData.error) {
            throw new Error(responseData.error);
        }

        return {
            default: `http://localhost:5000/assets/articleImage/${responseData.fileName}`,
        };
    }

    abort() {
        // Implement abort logic if necessary
    }
}