
// import { useEffect, useState } from 'react'
// import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';
// import { Select, Option } from "@material-tailwind/react";


// export default function AddAuthor({ open, setOpen, handleAdd, currentData, setCurrentData }) {
//     const [formData, setFormData] = useState({
//         name: '',
//         email: '',
//         // password: '',
//         bio: '',
//         // userName: '',
//         status:""

//     });

//     useEffect(() => {
//         if (currentData) {
//             setFormData({
//                 id: currentData.id,
//                 name: currentData.name,
//                 email: currentData.email,
//                 // password: currentData.password,
//                 bio:currentData.bio,
//                 // userName:currentData.userName,
//                 status:currentData.status
//             });
//         }
//     }, [currentData]);

//     const handleOpen = () => {
//         setOpen(!open);
//         setFormData({
//             name: '',
//             email: '',
//             // password: '',
//             bio: '',
//             // userName:'',
//             status:""
//         });

//         setCurrentData(null)

//     };


//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setFormData({ ...formData, [name]: value });
//     };

//     const handleSubmit = () => {
//         handleAdd(formData);
//         handleOpen();
//     };

//     const handleOptionChange = (value) => {
//         setFormData({ ...formData, status: value });
//     };

//     return (
//         <>
//             <Button onClick={handleOpen} variant="gradient">
//                 Add Author
//             </Button>

//             <Dialog open={open} size="lg" handler={handleOpen}>


//                 <DialogHeader >
//                     <div>
//                         {currentData ? "Edit Author" : "Add Author"}
//                     </div>
//                 </DialogHeader>

//                 <DialogBody >
//                     <div className="flex flex-wrap gap-5" >


//                         <div className="w-[48%]">

//                             <Input
//                                 name="name"
//                                 label="Name"
//                                 value={formData.name}
//                                 onChange={handleChange}
//                             />
//                         </div>

//                         <div className="w-[48%]">

//                             <Input
//                                 name="email"
//                                 label="Email"
//                                 value={formData.email}
//                                 onChange={handleChange}
//                             />
//                         </div>

//                         {/* <div className="w-[48%]">

//                             <Input
//                                 name="password"
//                                 label="Password"
//                                 value={formData.password}
//                                 onChange={handleChange}
//                             />
//                         </div> */}

//                         <div className="w-[48%]">
//                             <Input
//                                 name="bio"
//                                 label="Bio"
//                                 value={formData.bio}
//                                 onChange={handleChange}
//                             />
//                         </div>

//                         {/* <div className="w-[48%]">
//                             <Input
//                                 name="userName"
//                                 label="UserName"
//                                 value={formData.userName}
//                                 onChange={handleChange}
//                             />
//                         </div> */}

//                         <div className="w-[48%]">
//                             <Select label='Status' className="w-full" name="status" value={formData.status} onChange={handleOptionChange}>
//                                 <Option value="active">Active</Option>
//                                 <Option value="inactive">Inactive</Option>
//                             </Select>
//                         </div>

//                     </div>
//                 </DialogBody>

//                 <DialogFooter>

//                     <div className="mt-4">
//                         <Button
//                             variant="text"
//                             color="red"
//                             onClick={handleOpen}
//                             className="mr-1"
//                         >
//                             <span>Cancel</span>
//                         </Button>
//                         <Button variant="gradient" color="green" onClick={handleSubmit}>
//                             <span>{currentData ? "Update Author" : "Add Author"}</span>
//                         </Button>
//                     </div>
//                 </DialogFooter>


//             </Dialog>
//         </>
//     )
// }



import { useEffect, useState } from 'react';
import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';
import { Select, Option } from '@material-tailwind/react';

import axios from 'axios';

export default function AddAuthor({ open, setOpen, handleAdd, currentData, setCurrentData,setFormsubmit}) {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        bio: '',
        status: '',
        image: '',
    });

    const [images, setImages] = useState([]); // State to store image URLs
    const [selectedImage, setSelectedImage] = useState(null); // Track the uploaded image

    useEffect(() => {
        if (currentData) {
            setFormData({
                id: currentData.id,
                name: currentData.name,
                email: currentData.email,
                bio: currentData.bio,
                status: currentData.status,
                image: currentData.image,
            });
        }
    }, [currentData]);

    const handleOpen = () => {
        setOpen(!open);
        setFormData({ name: '', email: '', bio: '', status: '', image: '' });
        setCurrentData(null);
        setImages([]); // Clear the images on dialog close
        setSelectedImage(null);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const uploadImages = async (ev) => {
        const files = ev.target?.files;
        if (files?.length > 0) {
            const data = new FormData();
            for (const file of files) {
                data.append('file', file);
            }
            const res = await axios.post('/api/upload', data);
            console.log(res);

            if (res.status === 200 && res.data.links) {
                setImages(res.data.links); // Save the returned image links
                setFormData({ ...formData, image: res.data.links[0] }); // Set the first image URL in formData
            }
        }
    };

    const handleSubmit = () => {
        console.log("formdata", formData);
    
        // If no new image is selected, retain the current image
        const updatedData = {
            ...formData,
            image: formData.image || (currentData && currentData.image), 
        };
    
        handleAdd(updatedData);
        handleOpen();
        setFormsubmit(true);
    };
    
   
    return (
        <>
            <Button onClick={handleOpen} variant="gradient">
                Add Author
            </Button>

            <Dialog open={open} size="lg" handler={handleOpen}>
                <DialogHeader>{currentData ? 'Edit Author' : 'Add Author'}</DialogHeader>
                <DialogBody>
                    <div className="flex flex-wrap gap-5">
                        <Input name="name" label="Name" value={formData.name} onChange={handleChange} />
                        <Input name="email" label="Email" value={formData.email} onChange={handleChange} />
                        <Input name="bio" label="Bio" value={formData.bio} onChange={handleChange} />
                        <Select
                            label="Status"
                            value={formData.status}
                            onChange={(value) => setFormData({ ...formData, status: value })}
                        >
                            <Option value="active">Active</Option>
                            <Option value="inactive">Inactive</Option>
                        </Select>
                        <div>
                            <input type="file" onChange={uploadImages} />
                        </div>
                        {/* Display the uploaded image */}
                        {images.length > 0 && (
                            <div className="mt-4">
                                <img src={images[0]} alt="Uploaded" className="w-32 h-32 object-cover" />
                            </div>
                        )}
                    </div>
                </DialogBody>
                <DialogFooter>
                    <Button variant="text" color="red" onClick={handleOpen}>
                        Cancel
                    </Button>
                    <Button variant="gradient" color="green" onClick={handleSubmit}>
                        {currentData ? 'Update Author' : 'Add Author'}
                    </Button>
                </DialogFooter>
            </Dialog>
        </>
    );
}
