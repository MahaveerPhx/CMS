import { useEffect, useState } from "react";
import {
  Button,
  Input,
  Dialog,
  DialogFooter,
  DialogHeader,
  DialogBody,
  IconButton,
} from "@material-tailwind/react";
import { PlusIcon, TrashIcon } from "@heroicons/react/24/solid";

export default function AddCategory({
  open,
  setOpen,
  handleAdd,
  currentData,
  setCurrentData,
}) {
  const [formData, setFormData] = useState({
    name: "",
    slug: "",
    subCategories: [],
  });

  useEffect(() => {
    if (currentData) {
      setFormData({
        id: currentData.id,
        name: currentData.name,
        slug: currentData.slug,
        subCategories: currentData.subCategories || [],
      });
    }
  }, [currentData]);

  const handleOpen = () => {
    setOpen(!open);
    setFormData({
      name: "",
      subCategories: [],
    });

    setCurrentData(null);
  };

  const handleChange = (e, index = null, subIndex = null) => {
    const { name, value } = e.target;

    if (index === null) {
      setFormData({ ...formData, [name]: value });
    } else {
      const updatedSubCategories = [...formData.subCategories];
      if (subIndex === null) {
        updatedSubCategories[index][name] = value;
      } else {
        updatedSubCategories[index].subCategories[subIndex][name] = value;
      }
      setFormData({ ...formData, subCategories: updatedSubCategories });
    }
  };

  const addSubCategory = (index = null) => {
    if (index === null) {
      setFormData({
        ...formData,
        subCategories: [
          ...formData.subCategories,
          { name: "", subCategories: [] },
        ],
      });
    } else {
      const updatedSubCategories = [...formData.subCategories];
      updatedSubCategories[index].subCategories.push({
        name: "",
        subCategories: [],
      });
      setFormData({ ...formData, subCategories: updatedSubCategories });
    }
  };

  const removeSubCategory = (index, subIndex = null) => {
    const updatedSubCategories = [...formData.subCategories];
    if (subIndex === null) {
      updatedSubCategories.splice(index, 1);
    } else {
      updatedSubCategories[index].subCategories.splice(subIndex, 1);
    }
    setFormData({ ...formData, subCategories: updatedSubCategories });
  };

  const handleSubmit = () => {
    handleAdd(formData);
    handleOpen();
  };

  const renderSubCategoryFields = (subCategories, parentIndex = null) => {
    return subCategories.map((subCategory, index) => (
      <div key={index} className="flex items-center gap-2 ml-6 mb-2">
        <Input
          name="name"
          label={`Subcategory ${
            parentIndex !== null ? `${parentIndex + 1}.${index + 1}` : index + 1
          }`}
          value={subCategory.name}
          onChange={(e) =>
            handleChange(
              e,
              parentIndex !== null ? parentIndex : index,
              parentIndex !== null ? index : null
            )
          }
          className="w-full"
        />
        <IconButton
          variant="text"
          color="red"
          onClick={() =>
            removeSubCategory(
              parentIndex !== null ? parentIndex : index,
              parentIndex !== null ? index : null
            )
          }
        >
          <TrashIcon className="h-5 w-5" />
        </IconButton>
        <Button
          variant="outlined"
          size="sm"
          onClick={() =>
            addSubCategory(parentIndex !== null ? parentIndex : index)
          }
        >
          <PlusIcon className="h-5 w-5" />
        </Button>
        {subCategory.subCategories &&
          renderSubCategoryFields(
            subCategory.subCategories,
            parentIndex !== null ? parentIndex : index
          )}
      </div>
    ));
  };

  return (
    <>
      <Button onClick={handleOpen} variant="gradient">
        Add Category
      </Button>

      <Dialog open={open} size="xxl" handler={handleOpen}>
        <DialogHeader>
          <div>{currentData ? "Edit Category" : "Add Category"}</div>
        </DialogHeader>

        <DialogBody>
          <div className="flex flex-wrap gap-5">
            <div className="w-full">
              <Input
                name="name"
                label="Category Name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>
            <div className="w-full">
              <Input
                name="slug"
                label="Slug"
                value={formData.slug}
                onChange={handleChange}
              />
            </div>
            <div className="w-full">
              {renderSubCategoryFields(formData.subCategories)}
              <Button
                variant="outlined"
                size="sm"
                onClick={() => addSubCategory()}
                className="mt-4"
              >
                Add Subcategory
              </Button>
            </div>
          </div>
        </DialogBody>

        <DialogFooter>
          <Button
            variant="text"
            color="red"
            onClick={handleOpen}
            className="mr-1"
          >
            <span>Cancel</span>
          </Button>
          <Button variant="gradient" color="green" onClick={handleSubmit}>
            <span>{currentData ? "Update Category" : "Add Category"}</span>
          </Button>
        </DialogFooter>
      </Dialog>
    </>
  );
}
