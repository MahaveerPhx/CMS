
import { useEffect, useState } from 'react'
import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';
import { Select, Option } from "@material-tailwind/react";
import { useUploadFileMutation } from '@/globalStates/webApiSlice';


export default function AddFiles({ open, setOpen, handleAdd, currentData, setCurrentData }) {
    const [uploadFile] = useUploadFileMutation();
    const [formData, setFormData] = useState({
        type: 'image',
        fileName: '',
    });

    const mimeTypes = {
        image: 'image/*',
        video: 'video/*',
        audio: 'audio/*'
    };


    useEffect(() => {
        if (currentData) {
            setFormData({
                id: currentData.id,
                type: currentData.type,
                fileName: currentData.fileName,

            });
        }
    }, [currentData]);

    const handleOpen = () => {
        setOpen(!open);
        setFormData({
            type: 'image',
            fileName: '',
        });

        setCurrentData(null)

    };

    const handleSubmit = () => {
        handleAdd(formData);
        handleOpen();
    };

    const handleFileUpload = async (event) => {
        console.log("i am here")
        const files = event.target?.files;
        console.log("files: ", files)
        console.log("i am here 2")
        if (files?.length > 0) {
            const data = new FormData();
            for (const file of files) {
                data.append("file", file);
            }

            data.append("type", formData.type);

            try {
                console.log("data: ", data)
                const response = await uploadFile(data).unwrap();

                const fileName = response.fileName;

                setFormData({ ...formData, fileName: fileName });
            } catch (error) {
                console.error("File upload failed:", error);
            }
        }
    };


    return (
        <>
            <Button onClick={handleOpen} variant="gradient">
                Add File
            </Button>

            <Dialog open={open} size="lg" handler={handleOpen}>
                <DialogHeader >
                    <div>
                        {currentData ? "Edit File" : "Add File"}
                    </div>
                </DialogHeader>

                <DialogBody >
                    <div className="flex flex-wrap gap-5" >
                        <div className="w-[48%]">
                            <Select label="Select File Type" value={formData.type} onChange={(value) => setFormData({ ...formData, type: value })}>
                                <Option value={'image'}>Image</Option>
                                <Option value={'video'}>Video</Option>
                                <Option value={'audio'}>Audio</Option>
                            </Select>
                        </div>

                        <div className="w-[48%]">
                            <label htmlFor="file-input" className="sr-only">Choose file</label>
                            <input
                                type="file"
                                name="file-input"
                                id="file-input"
                                className="block mb-5 w-full border border-gray-200 shadow-sm rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400
                                    file:bg-gray-50 file:border-0
                                    file:me-4
                                    file:py-3 file:px-4
                                    dark:file:bg-neutral-700 dark:file:text-neutral-400"
                                onChange={(event) => handleFileUpload(event)}
                                accept={mimeTypes[formData.type]} // Dynamically set the accepted file types
                            />
                        </div>

                    </div>
                </DialogBody>

                <DialogFooter>

                    <div className="mt-4">
                        <Button
                            variant="text"
                            color="red"
                            onClick={handleOpen}
                            className="mr-1"
                        >
                            <span>Cancel</span>
                        </Button>
                        <Button variant="gradient" color="green" onClick={handleSubmit}>
                            <span>{currentData ? "Update File" : "Add File"}</span>
                        </Button>
                    </div>
                </DialogFooter>
            </Dialog>
        </>
    )
}