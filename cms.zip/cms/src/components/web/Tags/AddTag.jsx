
import { useEffect, useState } from 'react'
import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';


export default function AddTag({ open, setOpen, handleAdd, currentData, setCurrentData }) {
    const [formData, setFormData] = useState({
        name: '',
    });

    useEffect(() => {
        if (currentData) {
            setFormData({
                id: currentData.id,
                name: currentData.name,
                
            });
        }
    }, [currentData]);

    const handleOpen = () => {
        setOpen(!open);
        setFormData({
            name: '',
           
        });

        setCurrentData(null)

    };


    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = () => {
        handleAdd(formData);
        handleOpen();
    };

    return (
        <>
            <Button onClick={handleOpen} variant="gradient">
                Add Tag
            </Button>

            <Dialog open={open} size="lg" handler={handleOpen}>


                <DialogHeader >
                    <div>
                        {currentData ? "Edit Tag" : "Add Tag"}
                    </div>
                </DialogHeader>

                <DialogBody >
                    <div className="flex flex-wrap gap-5" >


                        <div className="w-[48%]">

                            <Input
                                name="name"
                                label="Name"
                                value={formData.name}
                                onChange={handleChange}
                            />
                        </div>

                    </div>
                </DialogBody>

                <DialogFooter>

                    <div className="mt-4">
                        <Button
                            variant="text"
                            color="red"
                            onClick={handleOpen}
                            className="mr-1"
                        >
                            <span>Cancel</span>
                        </Button>
                        <Button variant="gradient" color="green" onClick={handleSubmit}>
                            <span>{currentData ? "Update Tag" : "Add Tag"}</span>
                        </Button>
                    </div>
                </DialogFooter>


            </Dialog>
        </>
    )
}