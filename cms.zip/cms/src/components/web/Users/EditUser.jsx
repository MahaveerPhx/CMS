
// import { useEffect, useState } from 'react'
// import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';


// export default function EditUser({ open, setOpen, handleAdd, currentData, setCurrentData }) {
//     const [formData, setFormData] = useState({
//         name: '',
//         email: '',
//         password: '',
//         gender: '',
//         city: '',
//         state:""

//     });

//     useEffect(() => {
//         if (currentData) {
//             setFormData({
//                 id: currentData.id,
//                 name: currentData.name,
//                 email: currentData.email,
//                 password: currentData.password,
//                 gender: currentData.gender,
//                 city: currentData.city,
//                 state:currentData.state
//             });
//         }
//     }, [currentData]);

//     const handleOpen = () => {
//         setOpen(!open);
//         setFormData({
//             name: '',
//             email: '',
//             password: '',
//             gender: '',
//             city: '',
//             state:""
//         });

//         setCurrentData(null)

//     };


//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setFormData({ ...formData, [name]: value });
//     };

//     const handleSubmit = () => {
//         handleAdd(formData);
//         handleOpen();
//     };


//     return (
//         <>
//             <Button onClick={handleOpen} variant="gradient">
//                 Edit User
//             </Button>

//             <Dialog open={open} size="lg" handler={handleOpen}>


//                 <DialogHeader >
//                     <div>
//                         {currentData ? "Edit User" : " "}
//                     </div>
//                 </DialogHeader>

//                 <DialogBody >
//                     <div className="flex flex-wrap gap-5" >


//                         <div className="w-[48%]">

//                             <Input
//                                 name="name"
//                                 label="Name"
//                                 value={formData.name}
//                                 onChange={handleChange}
//                             />
//                         </div>

//                         <div className="w-[48%]">

//                             <Input
//                                 name="email"
//                                 label="Email"
//                                 value={formData.email}
//                                 onChange={handleChange}
//                             />
//                         </div>

//                         <div className="w-[48%]">

//                             <Input
//                                 name="password"
//                                 label="Password"
//                                 value={formData.password}
//                                 onChange={handleChange}
//                             />
//                         </div>

//                         <div className="w-[48%]">
//                             <Input
//                                 name="gender"
//                                 label="Gender"
//                                 value={formData.gender}
//                                 onChange={handleChange}
//                             />
//                         </div>

//                         <div className="w-[48%]">
//                             <Input
//                                 name="city"
//                                 label="City"
//                                 value={formData.city}
//                                 onChange={handleChange}
//                             />
//                         </div>

//                         <div className="w-[48%]">
//                             <Input
//                                 name="state"
//                                 label="State"
//                                 value={formData.state}
//                                 onChange={handleChange}
//                             />
//                         </div>


//                     </div>
//                 </DialogBody>

//                 <DialogFooter>

//                     <div className="mt-4">
//                         <Button
//                             variant="text"
//                             color="red"
//                             onClick={handleOpen}
//                             className="mr-1"
//                         >
//                             <span>Cancel</span>
//                         </Button>
//                         <Button variant="gradient" color="green" onClick={handleSubmit}>
//                             <span>{currentData ? "Update User" : " "}</span>
//                         </Button>
//                     </div>
//                 </DialogFooter>


//             </Dialog>
//         </>
//     )
// }

//=======================================================================================

import { useEffect, useState } from 'react';
import { Button, Input, Dialog, DialogFooter, DialogHeader, DialogBody } from '@material-tailwind/react';

export default function EditUser({ open, setOpen, handleAdd, currentData, setCurrentData, tableHeaders }) {
    const [formData, setFormData] = useState({});

    useEffect(() => {
        if (currentData) {
            // Populate formData dynamically based on currentData keys
            setFormData(currentData);
        } else {
            // Initialize formData with empty values for all headers
            const emptyData = {};
            tableHeaders.forEach(header => {
                if (header !== 'Actions') {
                    emptyData[header] = '';
                }
            });
            setFormData(emptyData);
        }
    }, [currentData, tableHeaders]);

    const handleOpen = () => {
        setOpen(!open);
        setFormData({});
        setCurrentData(null);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = () => {
        handleAdd(formData);
        handleOpen();
    };

    return (
        <>
            <Button onClick={handleOpen} variant="gradient">
                Edit User
            </Button>

            <Dialog open={open} size="lg" handler={handleOpen}>
                <DialogHeader>
                    <div>
                        {currentData ? "Edit User" : "Add User"}
                    </div>
                </DialogHeader>

                <DialogBody>
                    <div className="flex flex-wrap gap-5">
                        {tableHeaders.map((header, index) => {
                            if (header === 'Actions') return null; // Skip the "Actions" column
                            return (
                                <div key={index} className="w-[48%]">
                                    <Input
                                        name={header}
                                        label={header.charAt(0).toUpperCase() + header.slice(1)} // Capitalize label
                                        value={formData[header] || ''}
                                        onChange={handleChange}
                                    />
                                </div>
                            );
                        })}
                    </div>
                </DialogBody>

                <DialogFooter>
                    <div className="mt-4">
                        <Button
                            variant="text"
                            color="red"
                            onClick={handleOpen}
                            className="mr-1"
                        >
                            <span>Cancel</span>
                        </Button>
                        <Button variant="gradient" color="green" onClick={handleSubmit}>
                            <span>{currentData ? "Update User" : "Add User"}</span>
                        </Button>
                    </div>
                </DialogFooter>
            </Dialog>
        </>
    );
}
