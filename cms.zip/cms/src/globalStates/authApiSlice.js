
import { AUTH_ROUTE, LOGIN_ROUTE, SWITCH_PANEL_ROUTE } from '@/utils/ApiRoutes';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const authApiSlice = createApi({
    reducerPath: 'authApi',
    baseQuery: fetchBaseQuery({ baseUrl: AUTH_ROUTE }),
    endpoints: (builder) => ({

        switchWebPanel: builder.mutation({
            query: (data) => ({
                url: SWITCH_PANEL_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        checkUser: builder.mutation({
            query: (data) => ({
                url: LOGIN_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        

    }),
});

export const { useSwitchWebPanelMutation, useCheckUserMutation } = authApiSlice;
