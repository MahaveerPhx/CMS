// dataSlice.js

import { createSlice } from "@reduxjs/toolkit";

const dataSlice = createSlice({
  name: "data",

  initialState: {
    isLogin: false,
    isWebLogin: false,
    role: null,
    adminName: null,
    adminId: null,
    websiteName: null,
  },

  reducers: {
    setIsLogin: (state, action) => {
      state.isLogin = action.payload;
    },

    setIsWebLogin: (state, action) => {
      state.isWebLogin = action.payload;
    },

    setRole: (state, action) => {
      state.role = action.payload;
    },

    setAdminName: (state, action) => {
      state.adminName = action.payload;
    },

    setAdminId: (state, action) => {
      state.adminId = action.payload;
    },

    setWebsiteName: (state, action) => {
      state.websiteName = action.payload;
    },
  },
});

export const {
  setIsLogin,
  setIsWebLogin,
  setRole,
  setAdminName,
  setAdminId,
  setWebsiteName,
} = dataSlice.actions;

export default dataSlice.reducer;
