import {
  ADD_ADMIN_ROUTE,
  ADD_WEBSITE_ADMIN_ROUTE,
  ADD_WEBSITE_ROUTE,
  DELETE_ADMIN_ROUTE,
  DELETE_WEBSITE_ADMIN_ROUTE,
  DELETE_WEBSITE_ROUTE,
  GET_ADMINS_ROUTE,
  GET_ALL_WEBSITE_DETAILS_ROUTE,
  GET_MASTER_DATA_ROUTE,
  GET_WEBSITE_ADMINS_ROUTE,
  GET_WEBSITES_ROUTE,
  MASTER_ROUTE,
  UPDATE_ADMIN_ROUTE,
  UPDATE_WEBSITE_ADMIN_ROUTE,
  UPDATE_WEBSITE_ROUTE,
} from "@/utils/ApiRoutes";
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const masterApiSlice = createApi({
  reducerPath: "masterApi",
  baseQuery: fetchBaseQuery({ baseUrl: MASTER_ROUTE }),
  endpoints: (builder) => ({
    getWebsites: builder.mutation({
      query: (data) => ({
        url: GET_WEBSITES_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    addWebsite: builder.mutation({
      query: (data) => ({
        url: ADD_WEBSITE_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    updateWebsite: builder.mutation({
      query: (data) => ({
        url: UPDATE_WEBSITE_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    deleteWebsite: builder.mutation({
      query: (id) => ({
        url: DELETE_WEBSITE_ROUTE,
        method: "POST",
        body: { id },
      }),
    }),

    getAdmins: builder.mutation({
      query: (data) => ({
        url: GET_ADMINS_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    addAdmin: builder.mutation({
      query: (data) => ({
        url: ADD_ADMIN_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    updateAdmin: builder.mutation({
      query: (data) => ({
        url: UPDATE_ADMIN_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    deleteAdmin: builder.mutation({
      query: (id) => ({
        url: DELETE_ADMIN_ROUTE,
        method: "POST",
        body: { id },
      }),
    }),

    getWebsiteAdmins: builder.mutation({
      query: (data) => ({
        url: GET_WEBSITE_ADMINS_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    addWebsiteAdmins: builder.mutation({
      query: (data) => ({
        url: ADD_WEBSITE_ADMIN_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    updateWebsiteAdmins: builder.mutation({
      query: (data) => ({
        url: UPDATE_WEBSITE_ADMIN_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    deleteWebsiteAdmins: builder.mutation({
      query: (id) => ({
        url: DELETE_WEBSITE_ADMIN_ROUTE,
        method: "POST",
        body: { id },
      }),
    }),

    getMasterData: builder.mutation({
      query: (data) => ({
        url: GET_MASTER_DATA_ROUTE,
        method: "POST",
        body: data,
      }),
    }),

    getAllWebsiteDetails: builder.query({
      query: () => ({
        url: GET_ALL_WEBSITE_DETAILS_ROUTE,
        method: "GET",
      }),
    }),
  }),
});

export const {
  useGetWebsitesMutation,
  useAddWebsiteMutation,
  useDeleteWebsiteMutation,
  useUpdateWebsiteMutation,

  useGetAdminsMutation,
  useAddAdminMutation,
  useUpdateAdminMutation,
  useDeleteAdminMutation,
  useGetWebsiteAdminsMutation,

  useAddWebsiteAdminsMutation,
  useDeleteWebsiteAdminsMutation,
  useUpdateWebsiteAdminsMutation,
  useGetMasterDataMutation,
  useGetAllWebsiteDetailsQuery,
} = masterApiSlice;
