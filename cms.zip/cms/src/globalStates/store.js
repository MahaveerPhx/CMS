import { configureStore } from '@reduxjs/toolkit';
import persistedReducer from './persist';
import { persistStore } from 'redux-persist';
import { masterApiSlice } from './masterApiSlice';
import { webApiSlice } from './webApiSlice';
import { authApiSlice } from './authApiSlice';

const store = configureStore({
  reducer: {
    data: persistedReducer,
    [masterApiSlice.reducerPath]: masterApiSlice.reducer,
    [webApiSlice.reducerPath]: webApiSlice.reducer,
    [authApiSlice.authApiSlice]: authApiSlice.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }).concat(masterApiSlice.middleware, webApiSlice.middleware, authApiSlice.middleware),
});

const persistor = persistStore(store);

export { store, persistor };
