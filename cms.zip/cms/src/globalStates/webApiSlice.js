
import { IMAGE_UPLOAD_ROUTE, ADD_ARTICLE_ROUTE, ADD_AUTHOR_ROUTE, DELETE_ARTICLE_ROUTE, DELETE_AUTHOR_ROUTE, DELETE_COMMENT_ROUTE, DELETE_EVENT_ROUTE, DELETE_USER_ROUTE, GET_ARTICLES_ROUTE, GET_AUTHORS_ROUTE, GET_COMMENTS_ROUTE, GET_EVENTS_ROUTE, GET_USERS_ROUTE, UPDATE_ARTICLE_ROUTE, UPDATE_AUTHOR_ROUTE, UPDATE_USER_ROUTE, WEB_ROUTE, GET_CATEGORIES_ROUTE, ADD_CATEGORY_ROUTE, UPDATE_CATEGORY_ROUTE, DELETE_CATEGORY_ROUTE, DELETE_TAG_ROUTE, UPDATE_TAG_ROUTE, ADD_TAG_ROUTE, GET_DATA_ROUTE, DELETE_AD_ROUTE, UPDATE_AD_ROUTE, ADD_AD_ROUTE, GET_ADS_ROUTE, GET_TAGS_ROUTE, GET_FILES_ROUTE, ADD_FILE_ROUTE, UPDATE_FILE_ROUTE, DELETE_FILE_ROUTE, UPLOAD_FILE_ROUTE } from '@/utils/ApiRoutes';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const webApiSlice = createApi({
    reducerPath: 'webApi',
    baseQuery: fetchBaseQuery({ baseUrl: WEB_ROUTE }),
    endpoints: (builder) => ({

        uploadImage: builder.mutation({
            query: (data) => ({
                url: IMAGE_UPLOAD_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        getArticles: builder.mutation({
            query: (data) => ({
                url: GET_ARTICLES_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        addArticle: builder.mutation({
            query: (data) => ({
                url: ADD_ARTICLE_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),


        updateArticle: builder.mutation({
            query: (updatedOffer) => ({
                url: UPDATE_ARTICLE_ROUTE,
                method: 'POST',
                body: updatedOffer,
            }),
        }),

        deleteArticle: builder.mutation({
            query: (id) => ({
                url: DELETE_ARTICLE_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),


        getAuthors: builder.mutation({
            query: (data) => ({
                url: GET_AUTHORS_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        addAuthors: builder.mutation({
            query: (data) => ({
                url: ADD_AUTHOR_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        updateAuthors: builder.mutation({
            query: (updatedOffer) => ({
                url: UPDATE_AUTHOR_ROUTE,
                method: 'POST',
                body: updatedOffer,
            }),
        }),

        deleteAuthors: builder.mutation({
            query: (id) => ({
                url: DELETE_AUTHOR_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),

        getComments: builder.mutation({
            query: (data) => ({
                url: GET_COMMENTS_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        deleteComments: builder.mutation({
            query: (id) => ({
                url: DELETE_COMMENT_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),

        getUsers: builder.mutation({
            query: (data) => ({
                url: GET_USERS_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        updateUsers: builder.mutation({
            query: (updatedOffer) => ({
                url: UPDATE_USER_ROUTE,
                method: 'POST',
                body: updatedOffer,
            }),
        }),

        deleteUsers: builder.mutation({
            query: (id) => ({
                url: DELETE_USER_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),

        getEvents: builder.mutation({
            query: (data) => ({
                url: GET_EVENTS_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        deleteEvents: builder.mutation({
            query: (id) => ({
                url: DELETE_EVENT_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),

        getCatgories: builder.mutation({
            query: (data) => ({
                url: GET_CATEGORIES_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        addCategory: builder.mutation({
            query: (data) => ({
                url: ADD_CATEGORY_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        updateCategory: builder.mutation({
            query: (data) => ({
                url: UPDATE_CATEGORY_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        deleteCategory: builder.mutation({
            query: (id) => ({
                url: DELETE_CATEGORY_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),

        getTags: builder.mutation({
            query: (data) => ({
                url: GET_TAGS_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        addTags: builder.mutation({
            query: (data) => ({
                url: ADD_TAG_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),


        updateTags: builder.mutation({
            query: (updatedOffer) => ({
                url: UPDATE_TAG_ROUTE,
                method: 'POST',
                body: updatedOffer,
            }),
        }),

        deleteTags: builder.mutation({
            query: (id) => ({
                url: DELETE_TAG_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),


        getAds: builder.mutation({
            query: (data) => ({
                url: GET_ADS_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        addAds: builder.mutation({
            query: (data) => ({
                url: ADD_AD_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        updateAds: builder.mutation({
            query: (updatedOffer) => ({
                url: UPDATE_AD_ROUTE,
                method: 'POST',
                body: updatedOffer,
            }),
        }),

        deleteAds: builder.mutation({
            query: (id) => ({
                url: DELETE_AD_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),

        getFiles: builder.mutation({
            query: (data) => ({
                url: GET_FILES_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        addFile: builder.mutation({
            query: (data) => ({
                url: ADD_FILE_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        updateFile: builder.mutation({
            query: (data) => ({
                url: UPDATE_FILE_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        deleteFile: builder.mutation({
            query: (id) => ({
                url: DELETE_FILE_ROUTE,
                method: 'POST',
                body: { id },
            }),
        }),

        uploadFile: builder.mutation({
            query: (data) => ({
                url: UPLOAD_FILE_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

        getData: builder.mutation({
            query: (data) => ({
                url: GET_DATA_ROUTE,
                method: 'POST',
                body: data,
            }),
        }),

    }),
});


export const { useGetArticlesMutation, useAddArticleMutation, useUpdateArticleMutation, useDeleteArticleMutation, useUploadImageMutation,
    useGetAuthorsMutation, useAddAuthorsMutation, useUpdateAuthorsMutation, useDeleteAuthorsMutation, useGetCommentsMutation, useDeleteCommentsMutation,
    useGetTagsMutation, useUpdateAdsMutation, useGetUsersMutation, useUpdateUsersMutation, useDeleteUsersMutation, useGetEventsMutation, useDeleteEventsMutation,
    useAddCategoryMutation, useAddAdsMutation, useDeleteAdsMutation, useGetAdsMutation, useGetDataMutation, useGetCatgoriesMutation, useDeleteCategoryMutation,
    useUpdateCategoryMutation, useAddTagsMutation, useDeleteTagsMutation, useUpdateTagsMutation, useGetFilesMutation, useAddFileMutation, useUpdateFileMutation,
    useDeleteFileMutation, useUploadFileMutation
} = webApiSlice;
