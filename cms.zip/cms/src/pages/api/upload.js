import multipart from "multiparty";
import fs from "fs";
import path from "path";

export default async function handler(req, res) {
  const form = new multipart.Form();

  // Parse the incoming form data 
  const { fields, files } = await new Promise((resolve, reject) => {
    form.parse(req, (err, fields, files) => {
      if (err) reject(err);
      resolve({ fields, files });
    });
  });

  const authorDir = path.join(process.cwd(), "public", "author");

  // Ensure the author's directory exists inside "public/author"
  if (!fs.existsSync(authorDir)) {
    fs.mkdirSync(authorDir, { recursive: true });
  }

  const links = [];

  // Save uploaded files to the author's directory
  for (const file of files.file) {
    try {
      const ext = file.originalFilename.split(".").pop();
      const newFileName = Date.now() + "." + ext;

      const newFilePath = path.join(authorDir, newFileName);

      // Move the file to the author's directory
      fs.copyFileSync(file.path, newFilePath);

      // Generate a public URL for the file
      const link = `/author/${newFileName}`;
      links.push(link);
    } catch (error) {
      console.error("Error saving file locally:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  }

  // Respond with the links to the uploaded files
  return res.status(200).json({ links });
}

export const config = {
  api: { bodyParser: false },
};