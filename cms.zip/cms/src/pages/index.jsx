import MstDash from '@/components/master/Dashboard/MstDash'
import WebDash from '@/components/web/Dashboard/WebDash'
import React from 'react'
import { useSelector } from 'react-redux'

export default function Index() {

  const isWebLogin = useSelector((state) => state.data.isWebLogin)

  return (
    <>

      {
        !isWebLogin ?

          <MstDash />
          :
          <WebDash />

      }

    </>
  )
}
