import React from 'react'

const websiteGenre = () => {
  return (
    <div>website-genre</div>
  )
}

export default websiteGenre;