import {
  useAddWebsiteMutation,
  useDeleteWebsiteMutation,
  useGetWebsitesMutation,
  useGetWebsitesQuery,
  useUpdateWebsiteMutation,
} from "@/globalStates/masterApiSlice";
import { setIsWebLogin, setWebsiteName } from "@/globalStates/dataSlice";

import {
  PencilIcon,
  MagnifyingGlassIcon,
  TrashIcon,
  UsersIcon,
  MagnifyingGlassCircleIcon,
  ArrowLeftEndOnRectangleIcon,
} from "@heroicons/react/24/solid";
import {
  Card,
  Typography,
  Button,
  CardBody,
  CardFooter,
  IconButton,
  Tooltip,
  Input,
} from "@material-tailwind/react";
import { useRouter } from "next/router";

import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useSwitchWebPanelMutation } from "@/globalStates/authApiSlice";
import AddWebsite from "@/components/master/Websites/AddWebsite";

export default function Websites() {
  const dispatch = useDispatch();
  const router = useRouter();
  const [currentData, setCurrentData] = useState(null);
  const [column, setColumn] = useState([]);
  const [switchWebPanel] = useSwitchWebPanelMutation();
  const [getWebsites, { data, error, isLoading }] = useGetWebsitesMutation();
  const [addWebsite] = useAddWebsiteMutation();
  const [updateWebsite] = useUpdateWebsiteMutation();
  const [deleteWebsite] = useDeleteWebsiteMutation();

  const [open, setOpen] = useState(false);
  const [domain, setDomain] = useState("");

  const role = useSelector((state) => state.data.role);
  
  const fetchData = async (domain = "") => {
    const params = domain
      ? { domain, page: 1, limit: 10 }
      : { page: 1, limit: 10 };
    const response = await getWebsites(params);
    if (response?.data.columnNames) {
      setColumn(response.data.columnNames);
    }
  };

  const handleInputChange = (e) => {
    setDomain(e.target.value);
    fetchData(e.target.value);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAdd = async (data) => {
    try {
      if (currentData) {
        await updateWebsite({ ...data, id: currentData.id }).unwrap();
      } else {
        await addWebsite(data).unwrap();
      }
      setOpen(false);
      fetchData();
      setCurrentData(null);
    } catch (error) {
      console.error("Failed to add/update offer:", error);
    }
  };

  const handleEdit = (offer) => {
    setCurrentData(offer);
    setOpen(true);
  };

  async function handleDelete(id) {
    await deleteWebsite(id);
    fetchData();
  }

  async function websiteHandel(databaseDetail, siteName) {
    dispatch(setWebsiteName(siteName));
    dispatch(setIsWebLogin(true));
    await switchWebPanel(databaseDetail).unwrap();
    router.push("/");
  }

  return (
    <Card className="h-full w-full">
      <div className="rounded-none p-5">
        <div className="mb-4 flex flex-col justify-between gap-8 md:flex-row md:items-center">
          <div>
            <Typography variant="h5" color="blue-gray">
              Websites List
            </Typography>
          </div>
          <div className="flex w-full shrink-0 gap-2 md:w-max">
            <div className="w-full md:w-72">
              <Input
                label="Search"
                icon={<MagnifyingGlassIcon className="h-5 w-5" />}
                value={domain}
                onChange={handleInputChange}
              />
            </div>
            {role == "admin" ? (
              <AddWebsite
                open={open}
                setOpen={setOpen}
                handleAdd={handleAdd}
                currentData={currentData}
                setCurrentData={setCurrentData}
              />
            ) : (
              ""
            )}
          </div>
        </div>
      </div>

      <CardBody className="overflow-scroll px-0">
        <table className="w-full min-w-max table-auto text-left">
          <thead>
            <tr>
              {column &&
                column.map((col) => (
                  <th
                    key={col}
                    className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4"
                  >
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-normal leading-none opacity-70"
                    >
                      {col}
                    </Typography>
                  </th>
                ))}
              <th className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4">
                <Typography
                  variant="small"
                  color="blue-gray"
                  className="font-normal leading-none opacity-70"
                >
                  Actions
                </Typography>
              </th>
            </tr>
          </thead>
          <tbody>
            {data?.websites?.map((website, index) => (
              <tr key={index} className="hover:bg-gray-100">
                {column.map((col, colIndex) => (
                  <td key={colIndex} className="border border-gray-300 p-2">
                    {website[col]}
                  </td>
                ))}
                <td className="border border-gray-300 p-2">
                  <div className="flex space-x-2">
                    {role == "admin" ? (
                      <Tooltip content="Edit">
                        <IconButton
                          variant="text"
                          onClick={() => handleEdit(website)}
                        >
                          <PencilIcon className="h-4 w-4" />
                        </IconButton>
                      </Tooltip>
                    ) : (
                      ""
                    )}

                    {role == "admin" ? (
                      <Tooltip content="Delete">
                        <IconButton
                          variant="text"
                          onClick={() => handleDelete(website.id)}
                        >
                          <TrashIcon className="h-4 w-4" />
                        </IconButton>
                      </Tooltip>
                    ) : (
                      ""
                    )}

                    <Tooltip content="Manage Site">
                      <IconButton
                        variant="text"
                        onClick={() =>
                          websiteHandel(
                            {
                              databaseName: website.databaseName,
                              host: website.host,
                              user: website.user,
                              password: website.password,
                            },
                            website.name
                          )
                        }
                      >
                        <ArrowLeftEndOnRectangleIcon className="h-5 w-5" />
                      </IconButton>
                    </Tooltip>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardBody>

      <CardFooter className="flex items-center justify-between border-t border-blue-gray-50 p-4">
        <Button variant="outlined" size="sm">
          Previous
        </Button>
        <div className="flex items-center gap-2">
          <IconButton variant="text" size="sm" disabled>
            ...
          </IconButton>
          <IconButton variant="outlined" size="sm">
            1
          </IconButton>
          <IconButton variant="text" size="sm" disabled>
            ...
          </IconButton>
        </div>
        <Button variant="outlined" size="sm">
          Next
        </Button>
      </CardFooter>
    </Card>
  );
}
