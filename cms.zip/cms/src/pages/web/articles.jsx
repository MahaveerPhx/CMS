// import AddBrands from "@/components/Brands/AddBrands";
import AddArticle from "@/components/web/Articles/AddArticle";
import { useAddArticleMutation, useDeleteArticleMutation, useGetArticlesMutation, useUpdateArticleMutation } from "@/globalStates/webApiSlice";

import { PencilIcon, MagnifyingGlassIcon, TrashIcon,EyeIcon } from "@heroicons/react/24/solid";
import { Card, Typography, Button, CardBody, CardFooter, IconButton, Tooltip, Input } from "@material-tailwind/react";
import { useEffect, useState } from "react";
import { useSelector } from 'react-redux'



export default function Articles() {
    const [currentData, setCurrentData] = useState(null);
    const [columns, setColumns] = useState([]);

    const [getArticles, { data, error, isLoading }] = useGetArticlesMutation();
    const [addArticle] = useAddArticleMutation();
    const [updateArticle] = useUpdateArticleMutation();
    const [deleteArticle] = useDeleteArticleMutation();

    const adminName = useSelector((state) => state.data.adminName);

    const fetchData = async () => {
        const response = await getArticles({ page: 1, limit: 10 });
        if(response?.data.columnNames){
            setColumns(response.data.columnNames)
        }
    };

    useEffect(() => {
        fetchData()
    }, []);

    const [open, setOpen] = useState(false);

    const handleAdd = async (data) => {
        console.log("data: ", data)

        try {
            if (currentData) {

                await updateArticle({ ...data, id: currentData.id }).unwrap();
            } else {
                console.log('firs')
                await addArticle(data).unwrap();
            }
            setOpen(false);
            fetchData()
            setCurrentData(null);
        } catch (error) {

            console.error("Failed to add/update offer:", error);
        }
    };

    const handleEdit = (data) => {
        console.log("edit data: ", data)


        setCurrentData(data);
        setOpen(true);
    };

    async function handleDelete(id) {
        await deleteArticle(id)
        fetchData()
    }

    const filteredColumns = columns.filter((column) => column !== "content");

    return (

        <Card className="h-full w-full">

            <div className="rounded-none p-5">
                <div className="mb-4 flex flex-col justify-between gap-8 md:flex-row md:items-center">
                    <div>
                        <Typography variant="h5" color="blue-gray">
                            Article List
                        </Typography>
                    </div>
                    <div className="flex w-full shrink-0 gap-2 md:w-max">
                        <div className="w-full md:w-72">
                            <Input
                                label="Search"
                                icon={<MagnifyingGlassIcon className="h-5 w-5" />}
                            />
                        </div>
                        <AddArticle open={open} setOpen={setOpen} handleAdd={handleAdd} currentData={currentData} setCurrentData={setCurrentData} />
                    </div>
                </div>
            </div>

            <CardBody className="overflow-scroll px-0">
                <table className="w-full min-w-max table-auto text-left">

                    <thead>
                        <tr>
                            {filteredColumns.map((head) => (
                                <th
                                    key={head}
                                    className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4"
                                >
                                    <Typography
                                        variant="small"
                                        color="blue-gray"
                                        className="font-normal leading-none opacity-70"
                                    >
                                        {head}
                                    </Typography>
                                </th>
                            ))}
                            <th
                                className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4"
                            >
                                <Typography
                                    variant="small"
                                    color="blue-gray"
                                    className="font-normal leading-none opacity-70"
                                >
                                    Preview
                                </Typography>
                            </th>

                            <th
                                className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4"
                            >
                                <Typography
                                    variant="small"
                                    color="blue-gray"
                                    className="font-normal leading-none opacity-70"
                                >
                                    Actions
                                </Typography>
                            </th>
                        </tr>
                    </thead>

                    <tbody>

                        {data?.articles?.map(({ id, title,image,content, authorName, categoryName, status,createdAt,updatedAt,scheduleStartTime,scheduleEndTime,createdBy,updatedBy,authorId,categoryId
                        }, index) => {
                            const isLast = index === data?.articles.length - 1;
                            const classes = isLast ? "p-4" : "p-4 border-b border-blue-gray-50";
                           
                            return (
                                <tr key={index}>

                                    <td className={classes}>
                                        <div className="flex items-center gap-3">
                                            <Typography variant="small" color="blue-gray" className="font-bold">
                                                {id}
                                            </Typography>
                                        </div>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {title.length > 50 ? `${title.slice(0, 50)}...` : title}
                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {image}
                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {authorName}
                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {categoryName}
                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {status}
                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {new Date(createdAt).toLocaleDateString()}

                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {new Date(updatedAt).toLocaleDateString()}

                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {new Date(scheduleStartTime).toLocaleDateString()}

                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {new Date(scheduleEndTime).toLocaleDateString()}
                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {createdBy}
                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <Typography variant="small" color="blue-gray" className="font-normal">
                                            {updatedBy}
                                        </Typography>
                                    </td>

                                    <td className={classes}>
                                        <IconButton variant="text" onClick={() => handleDelete(id)}>
                                            <EyeIcon className="h-4 w-4" />
                                        </IconButton>
                                    </td>

                                    <td className={classes}>

                                        <Tooltip content="Edit">

                                            <IconButton variant="text" onClick={() => handleEdit({ id, title,content,image,authorId,categoryId,status,scheduleStartTime,scheduleEndTime,createdBy,updatedBy:adminName})}>
                                                <PencilIcon className="h-4 w-4" />
                                            </IconButton>
                                        </Tooltip>


                                        <Tooltip content="Delete">

                                            <IconButton variant="text" onClick={() => handleDelete(id)}>
                                                <TrashIcon className="h-4 w-4" />
                                            </IconButton>
                                        </Tooltip>

                                    </td>

                                </tr>
                            );

                        })}

                    </tbody>
                </table>
            </CardBody>

            <CardFooter className="flex items-center justify-between border-t border-blue-gray-50 p-4">
                <Button variant="outlined" size="sm">
                    Previous
                </Button>
                <div className="flex items-center gap-2">
                    <IconButton variant="text" size="sm" disabled>
                        ...
                    </IconButton>
                    <IconButton variant="outlined" size="sm">
                        1
                    </IconButton>
                    <IconButton variant="text" size="sm" disabled>
                        ...
                    </IconButton>
                </div>
                <Button variant="outlined" size="sm">
                    Next
                </Button>
            </CardFooter>

        </Card>
    );
}
