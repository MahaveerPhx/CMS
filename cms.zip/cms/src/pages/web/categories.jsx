import AddCategory from "@/components/web/Categories/AddCategory";
import {
  useAddCategoryMutation,
  useDeleteCategoryMutation,
  useGetCatgoriesMutation,
  useUpdateCategoryMutation,
} from "@/globalStates/webApiSlice";
import {
  PencilIcon,
  MagnifyingGlassIcon,
  TrashIcon,
} from "@heroicons/react/24/solid";
import {
  Card,
  Typography,
  Button,
  CardBody,
  CardFooter,
  IconButton,
  Tooltip,
  Input,
  Dialog,
  DialogHeader,
  DialogBody,
  DialogFooter,
} from "@material-tailwind/react";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";


export default function Categories() {
  const [currentData, setCurrentData] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [open, setOpen] = useState(false);
  const [SubModalOpen, setSubModalOpen] = useState(false);
  const [getCategories, { data, error, isLoading }] = useGetCatgoriesMutation();
  const [addCategory] = useAddCategoryMutation();
  const [updateCategory] = useUpdateCategoryMutation();
  const [deleteCategory] = useDeleteCategoryMutation();
  const [isMainCategory, setIsMainCategory] = useState(true);

  const fetchData = async () => {
    await getCategories({ page: 1, limit: 10 });
  };

  useEffect(() => {
    fetchData();
  }, []);

  console.log("data: ",data)

  const handleAdd = async (data) => {
    try {
      if (currentData) {
        await updateCategory({ ...data, id: currentData.id }).unwrap();
      } else {
        await addCategory(data).unwrap();
      }
      setOpen(false);
      fetchData();
      setCurrentData(null);
    } catch (error) {
      console.error("Failed to add/update category:", error);
    }
  };

  const handleEdit = (category) => {
    setCurrentData(category);
    setSubModalOpen(false);
    setOpen(true);
  };

  const handleViewSubcategories = (category) => {
    console.log("category: ",category)
    setSelectedCategory(category);
    setSubModalOpen(true);
  };

  async function handleDelete(id) {
    await deleteCategory(id);
    fetchData();
    setSubModalOpen(false);
  }

  // Recursive function to render nested categories
  const renderCategories = (categories, isMainCategory) => {
    console.log("categories: ",categories)
    return categories.map((category) => (
      <li key={category.id} className="ml-4">
        <div className="flex items-center justify-between">
          <Typography
            variant="small"
            color="blue-gray"
            className={isMainCategory ? "font-bold" : ""}
          >
            - {category.name}
          </Typography>
          <div className="flex gap-2">
            <Tooltip content="Edit">
              <IconButton
                variant="text"
                onClick={() => {
                  handleEdit(category);
                }}
              >
                <PencilIcon className="h-4 w-4" />
              </IconButton>
            </Tooltip>
            <Tooltip content="Delete">
              <IconButton
                variant="text"
                onClick={() => handleDelete(category.id)}
              >
                <TrashIcon className="h-4 w-4" />
              </IconButton>
            </Tooltip>
          </div>
        </div>
        {category.subCategory && category.subCategory.length > 0 && (
          <ul>{renderCategories(category.subCategory, false)}</ul>
        )}
      </li>
    ));
  };

  const TABLE_HEAD = (data?.columnNames || []).filter((col) =>
    ["id", "name", "slug"].includes(col)
  );

  const handleInputChange = (e, field) => {
    const { value } = e.target;
    setSelectedCategory((prevCategory) => ({
      ...prevCategory,
      [field]: value,
    }));
  };
  const role = useSelector((state) => state.data.role);

  return (
    <Card className="h-full w-full">
      <div className="rounded-none p-5">
        <div className="mb-4 flex flex-col justify-between gap-8 md:flex-row md:items-center">
          <div>
            <Typography variant="h5" color="blue-gray">
              Categories List
            </Typography>
          </div>
          <div className="flex w-full shrink-0 gap-2 md:w-max">
            <div className="w-full md:w-72">
              <Input
                label="Search"
                icon={<MagnifyingGlassIcon className="h-5 w-5" />}
              />
            </div>
            {role == "admin" || role == "editor" ? (
              <AddCategory
                open={open}
                setOpen={setOpen}
                handleAdd={handleAdd}
                currentData={currentData}
                setCurrentData={setCurrentData}
                isMainCategory={isMainCategory}
              />
            ) : (
              ""
            )}
          </div>
        </div>
      </div>

      <CardBody className="overflow-scroll px-0">
        <table className="w-full min-w-max table-auto text-left">
          <thead>
            <tr>
              {TABLE_HEAD.map((head) => (
                <th
                  key={head}
                  className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4"
                >
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal leading-none opacity-70"
                  >
                    {head}
                  </Typography>
                </th>
              ))}
              <th className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4">
                <Typography
                  variant="small"
                  color="blue-gray"
                  className="font-normal leading-none opacity-70"
                >
                  Sub Categories
                </Typography>
              </th>

              {role == "admin" || role == "editor" ? (
                <th className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4">
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal leading-none opacity-70"
                  >
                    Actions
                  </Typography>
                </th>
              ) : (
                ""
              )}
            </tr>
          </thead>
          <tbody>
            {data?.categories?.map(
              ({ id, name,slug, subCategory }, index) => {
                const isLast = index === data?.categories.length - 1;
                const classes = isLast
                  ? "p-4"
                  : "p-4 border-b border-blue-gray-50";
                return (
                  <tr key={id}>
                    {TABLE_HEAD.map((head) => {
                      if (head === "id") {
                        return (
                          <td key={head} className={classes}>
                            <Typography
                              variant="small"
                              color="blue-gray"
                              className="font-bold"
                            >
                              {id}
                            </Typography>
                          </td>
                        );
                      }
                      if (head === "name") {
                        return (
                          <td key={head} className={classes}>
                            <Typography
                              variant="small"
                              color="blue-gray"
                              className="font-normal"
                            >
                              {name}
                            </Typography>
                          </td>
                        );
                      }
                      if (head === "slug") {
                        return (
                          <td key={head} className={classes}>
                            <Typography
                              variant="small"
                              color="blue-gray"
                              className="font-normal"
                            >
                              {slug}
                            </Typography>
                          </td>
                        );
                      }
                      return null; // In case you have other columns not defined in your data
                    })}

                    <td className={classes}>
                      <Button
                        color="blue-gray"
                        className="font-normal"
                        onClick={() =>
                          handleViewSubcategories({
                            id,
                            name,
                            slug,
                            subCategory,
                          })
                        }
                      >
                        Manage Sub Categories
                      </Button>
                    </td>

                    {/* for actions columns */}
                    {role == "admin" || role == "editor" ? (
                      <td className={classes}>
                        <Tooltip content="Edit">
                          <IconButton
                            variant="text"
                            onClick={() =>
                              handleEdit({
                                id,
                                name,
                                slug,
                                subCategory,
                              })
                            }
                          >
                            <PencilIcon className="h-4 w-4" />
                          </IconButton>
                        </Tooltip>

                        <Tooltip content="Delete">
                          <IconButton
                            variant="text"
                            onClick={() => handleDelete(id)}
                          >
                            <TrashIcon className="h-4 w-4" />
                          </IconButton>
                        </Tooltip>
                      </td>
                    ) : (
                      ""
                    )}
                  </tr>
                );
              }
            )}
          </tbody>
        </table>
      </CardBody>

      <CardFooter className="flex items-center justify-between border-t border-blue-gray-50 p-4">
        <Button variant="outlined" size="sm">
          Previous
        </Button>
        <div className="flex items-center gap-2">
          <IconButton variant="text" size="sm" disabled>
            ...
          </IconButton>
          <IconButton variant="outlined" size="sm">
            1
          </IconButton>
          <IconButton variant="text" size="sm" disabled>
            ...
          </IconButton>
        </div>
        <Button variant="outlined" size="sm">
          Next
        </Button>
      </CardFooter>

      {/* Modal for Viewing Subcategories */}
      {selectedCategory && (
        <Dialog open={SubModalOpen} handler={setSubModalOpen}>
          <DialogHeader>Subcategories for {selectedCategory.name}</DialogHeader>

          <DialogBody>
            <ul>{renderCategories([selectedCategory], true)}</ul>
          </DialogBody>
          <DialogFooter>
            <Button
              variant="text"
              color="red"
              onClick={() => setSubModalOpen(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </Dialog>
      )}
    </Card>
  );
}
