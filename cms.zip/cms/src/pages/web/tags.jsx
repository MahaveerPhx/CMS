import {
  PencilIcon,
  MagnifyingGlassIcon,
  TrashIcon,
} from "@heroicons/react/24/solid";
import {
  Card,
  Typography,
  Button,
  CardBody,
  CardFooter,
  IconButton,
  Tooltip,
  Input,
} from "@material-tailwind/react";

import { useEffect, useState } from "react";
import {
  useAddTagsMutation,
  useDeleteTagsMutation,
  useGetTagsMutation,
  useUpdateTagsMutation,
} from "@/globalStates/webApiSlice";
import AddTag from "@/components/web/Tags/AddTag";
import { useSelector } from "react-redux";

export default function Tag() {
  const TABLE_HEAD = ["id", "Name"];
  const [currentData, setCurrentData] = useState(null);

  const [getTags, { data, error, isLoading }] = useGetTagsMutation();
  const [addTags] = useAddTagsMutation();
  const [updateTags] = useUpdateTagsMutation();
  const [deleteTags] = useDeleteTagsMutation();

  const [open, setOpen] = useState(false);

  const fetchData = async () => {
    await getTags({ page: 1, limit: 10 });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAdd = async (data) => {
    try {
      if (currentData) {
        await updateTags({ ...data, id: currentData.id }).unwrap();
      } else {
        await addTags(data).unwrap();
      }
      setOpen(false);
      fetchData();
      setCurrentData(null);
    } catch (error) {
      console.error("Failed to add/update offer:", error);
    }
  };

  const handleEdit = (offer) => {
    setCurrentData(offer);
    setOpen(true);
  };

  async function handleDelete(id) {
    await deleteTags(id);
    fetchData();
  }
  const role = useSelector((state) => state.data.role);
  return (
    <Card className="h-full w-full">
      <div className="rounded-none p-5">
        <div className="mb-4 flex flex-col justify-between gap-8 md:flex-row md:items-center">
          <div>
            <Typography variant="h5" color="blue-gray">
              Tags List
            </Typography>
          </div>
          <div className="flex w-full shrink-0 gap-2 md:w-max">
            <div className="w-full md:w-72">
              <Input
                label="Search"
                icon={<MagnifyingGlassIcon className="h-5 w-5" />}
              />
            </div>
            {role == "admin" || role == "editor" ? (
              <AddTag
                open={open}
                setOpen={setOpen}
                handleAdd={handleAdd}
                currentData={currentData}
                setCurrentData={setCurrentData}
              />
            ) : (
              ""
            )}
          </div>
        </div>
      </div>

      <CardBody className="overflow-scroll px-0">
        <table className="w-full min-w-max table-auto text-left">
          <thead>
            <tr>
              {TABLE_HEAD.map((head) => (
                <th
                  key={head}
                  className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4"
                >
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal leading-none opacity-70"
                  >
                    {head}
                  </Typography>
                </th>
              ))}

              {role == "admin" || role == "editor" ? (
                <th className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4">
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal leading-none opacity-70"
                  >
                    Actions
                  </Typography>
                </th>
              ) : (
                ""
              )}
            </tr>
          </thead>
          <tbody>
            {data?.tags?.map(({ id, name }, index) => {
              const isLast = index === data?.tags - 1;
              const classes = isLast
                ? "p-4"
                : "p-4 border-b border-blue-gray-50";

              return (
                <tr key={index}>
                  <td className={classes}>
                    <div className="flex items-center gap-3">
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-bold"
                      >
                        {id}
                      </Typography>
                    </div>
                  </td>
                  <td className={classes}>
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-normal"
                    >
                      {name}
                    </Typography>
                  </td>
                  {role == "admin" || role == "editor" ? (
                    <td className={classes}>
                      <Tooltip content="Edit">
                        <IconButton
                          variant="text"
                          onClick={() => handleEdit({ id, name })}
                        >
                          <PencilIcon className="h-4 w-4" />
                        </IconButton>
                      </Tooltip>

                      <Tooltip content="Delete">
                        <IconButton
                          variant="text"
                          onClick={() => handleDelete(id)}
                        >
                          <TrashIcon className="h-4 w-4" />
                        </IconButton>
                      </Tooltip>
                    </td>
                  ) : (
                    ""
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </CardBody>

      <CardFooter className="flex items-center justify-between border-t border-blue-gray-50 p-4">
        <Button variant="outlined" size="sm">
          Previous
        </Button>
        <div className="flex items-center gap-2">
          <IconButton variant="text" size="sm" disabled>
            ...
          </IconButton>
          <IconButton variant="outlined" size="sm">
            1
          </IconButton>
          <IconButton variant="text" size="sm" disabled>
            ...
          </IconButton>
        </div>
        <Button variant="outlined" size="sm">
          Next
        </Button>
      </CardFooter>
    </Card>
  );
}
