import {
  PencilIcon,
  MagnifyingGlassIcon,
  TrashIcon,
} from "@heroicons/react/24/solid";
import {
  Card,
  Typography,
  Button,
  CardBody,
  CardFooter,
  IconButton,
  Tooltip,
  Input,
} from "@material-tailwind/react";
import { useEffect, useState } from "react";
import {
  useDeleteUsersMutation,
  useGetUsersMutation,
  useUpdateUsersMutation,
} from "@/globalStates/webApiSlice";
import EditUser from "@/components/web/Users/EditUser";

export default function User() {
  const [TABLE_HEAD, setTableHead] = useState([]); // Dynamic headers
  const [data, setData] = useState(null); // Users data
  const [filteredData, setFilteredData] = useState(null); // Filtered data for search
  const [searchQuery, setSearchQuery] = useState(""); // Search query
  const [currentData, setCurrentData] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);

  const [getUsers] = useGetUsersMutation();
  const [updateUsers] = useUpdateUsersMutation();
  const [deleteUsers] = useDeleteUsersMutation();

  const [open, setOpen] = useState(false);

  // Function to fetch data
  const fetchData = async (page = 1) => {
    try {
      const response = await getUsers({ page, limit: 10 }).unwrap();

      // Dynamically set table headers from the first user's keys
      if (response.users && response.users.length > 0) {
        const headers = Object.keys(response.users[0]);
        setTableHead([...headers, "Actions"]); // Add "Actions" for buttons
      }

      setData(response); // Set response data
      setFilteredData(response); // Initialize filtered data
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData(); // Fetch data on component mount
  }, []);

  useEffect(() => {
    // Filter data whenever the search query changes
    if (searchQuery.trim() === "") {
      setFilteredData(data);
    } else {
      const filtered = {
        ...data,
        users: data?.users.filter((user) =>
          user.FullName.toLowerCase().includes(searchQuery.toLowerCase())
        ),
      };
      setFilteredData(filtered);
    }
  }, [searchQuery, data]);

  // Function to convert ISO date to YYYY-MM-DD format
  const convertToDate = (isoDate) => {
    const date = new Date(isoDate);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Adding leading zero
    const day = date.getDate().toString().padStart(2, "0"); // Adding leading zero
    return `${year}-${month}-${day}`;
  };

  const handleAdd = async (userData) => {
    try {
      if (currentData) {
        await updateUsers({ ...userData, id: currentData.id }).unwrap();
      }
      setOpen(false);
      fetchData();
      setCurrentData(null);
    } catch (error) {
      console.error("Failed to add/update user:", error);
    }
  };

  const handleEdit = (user) => {
    // Convert Dob to the correct format
    const updatedUser = { ...user, Dob: convertToDate(user.Dob) };
    setCurrentData(updatedUser); // Set currentData with the converted DOB
    setOpen(true);
  };

  const handleDelete = async (id) => {
    try {
      await deleteUsers(id).unwrap();
      fetchData(currentPage);
    } catch (error) {
      console.error("Failed to delete user:", error);
    }
  };

  return (
    <Card className="h-full w-full">
      <div className="rounded-none p-5">
        <div className="mb-4 flex flex-col justify-between gap-8 md:flex-row md:items-center">
          <Typography variant="h5" color="blue-gray">
            Users List
          </Typography>
          <div className="flex w-full shrink-0 gap-2 md:w-max">
            <Input
              label="Search"
              icon={<MagnifyingGlassIcon className="h-5 w-5" />}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)} // Update search query
            />
          </div>
        </div>
      </div>

      <CardBody className="overflow-scroll px-0">
        <table className="w-full min-w-max table-auto text-left">
          <thead>
            <tr>
              {TABLE_HEAD.map((head, index) => (
                <th
                  key={index}
                  className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4"
                >
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal leading-none opacity-70"
                  >
                    {head}
                  </Typography>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredData?.users?.map((user, index) => {
              const isLast = index === filteredData?.users.length - 1;
              const classes = isLast
                ? "p-4"
                : "p-4 border-b border-blue-gray-50";

              return (
                <tr key={index}>
                  {TABLE_HEAD.slice(0, -1).map((key, idx) => (
                    <td key={idx} className={classes}>
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal"
                      >
                        {key === "Dob" ? convertToDate(user[key]) : user[key]}
                      </Typography>
                    </td>
                  ))}
                  <td className={classes}>
                    <Tooltip content="Edit">
                      <IconButton
                        variant="text"
                        onClick={() => handleEdit(user)}
                      >
                        <PencilIcon className="h-4 w-4" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip content="Delete">
                      <IconButton
                        variant="text"
                        onClick={() => handleDelete(user.id)}
                      >
                        <TrashIcon className="h-4 w-4" />
                      </IconButton>
                    </Tooltip>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </CardBody>

      <CardFooter className="flex items-center justify-between border-t border-blue-gray-50 p-4">
        <Button
          variant="outlined"
          size="sm"
          onClick={() => {
            if (currentPage > 1) {
              setCurrentPage((prev) => prev - 1);
              fetchData(currentPage - 1);
            }
          }}
        >
          Previous
        </Button>
        <Typography variant="small" color="blue-gray">
          Page {filteredData?.currentPage} of {filteredData?.totalPages}
        </Typography>
        <Button
          variant="outlined"
          size="sm"
          onClick={() => {
            if (currentPage < filteredData?.totalPages) {
              setCurrentPage((prev) => prev + 1);
              fetchData(currentPage + 1);
            }
          }}
        >
          Next
        </Button>
      </CardFooter>

      {open && (
        <EditUser
          open={open}
          setOpen={setOpen}
          currentData={currentData}
          handleAdd={handleAdd}
          setCurrentData={setCurrentData}
          tableHeaders={TABLE_HEAD} // Pass dynamic headers
        />
      )}
    </Card>
  );
}
