export let HOST;

if (typeof window !== "undefined") {
  if (window.location.origin.includes("localhost")) {
    HOST = "http://localhost:5001";
  } else {
    HOST = window.location.origin;
  }
} else {
  HOST = "http://localhost:5001";
}

HOST = `${HOST}/api`;

export const MASTER_ROUTE = `${HOST}/master-api`;
export const WEB_ROUTE = `${HOST}/web-api`;
export const AUTH_ROUTE = `${HOST}/auth-api`;

//auth-api
export const SWITCH_PANEL_ROUTE = `switchPanel`;
export const LOGIN_ROUTE = `checkUser`;

// master-api
//Websites API Routes
export const ADD_WEBSITE_ROUTE = "addWebsite";
export const GET_WEBSITES_ROUTE = "getWebsites";
export const UPDATE_WEBSITE_ROUTE = "updateWebsite";
export const DELETE_WEBSITE_ROUTE = "deleteWebsite";
export const GET_ALL_WEBSITE_DETAILS_ROUTE = "getAllWebsiteDetails";

//Admins API Routes
export const ADD_ADMIN_ROUTE = "addAdmin";
export const GET_ADMINS_ROUTE = "getAdmins";
export const UPDATE_ADMIN_ROUTE = "updateAdmin";
export const DELETE_ADMIN_ROUTE = "deleteAdmin";

//websiteAdmins API Routes
export const ADD_WEBSITE_ADMIN_ROUTE = "addWebsiteAdmin";
export const GET_WEBSITE_ADMINS_ROUTE = "getWebsiteAdmins";
export const UPDATE_WEBSITE_ADMIN_ROUTE = "updateWebsiteAdmin";
export const DELETE_WEBSITE_ADMIN_ROUTE = "deleteWebsiteAdmin";

//get Master data API Routes
export const GET_MASTER_DATA_ROUTE = "getMasterData";

// web-api
// Users API Routes
export const GET_USERS_ROUTE = "getUsers";
export const UPDATE_USER_ROUTE = "updateUser";
export const DELETE_USER_ROUTE = "deleteUser";

// Articles API Routes
export const ADD_ARTICLE_ROUTE = "addArticle";
export const GET_ARTICLES_ROUTE = "getArticles";
export const UPLOAD_IMAGE_ROUTE = `${WEB_ROUTE}/uploadImage`;
export const IMAGE_UPLOAD_ROUTE = "uploadImage";
export const UPDATE_ARTICLE_ROUTE = "updateArticle";
export const DELETE_ARTICLE_ROUTE = "deleteArticle";

// Authors API Routes
export const ADD_AUTHOR_ROUTE = "addAuthor";
export const GET_AUTHORS_ROUTE = "getAuthors";
export const UPDATE_AUTHOR_ROUTE = "updateAuthor";
export const DELETE_AUTHOR_ROUTE = "deleteAuthor";

// Comments API Routes
export const GET_COMMENTS_ROUTE = "getComments";
export const UPDATE_COMMENTS_ROUTE = "updateComment";
export const DELETE_COMMENTS_ROUTE = "deleteComment";
export const DELETE_COMMENT_ROUTE = "deleteComment";

// events API Routes
export const GET_EVENTS_ROUTE = "getEvents";
export const DELETE_EVENT_ROUTE = "deleteEvent";

//Categories API Routes
export const GET_CATEGORIES_ROUTE = "getCategories";
export const ADD_CATEGORY_ROUTE = "addCategory";
export const UPDATE_CATEGORY_ROUTE = "updateCategory";
export const DELETE_CATEGORY_ROUTE = "deleteCategory";

//tags API Routes
export const GET_TAGS_ROUTE = "getTags";
export const ADD_TAG_ROUTE = "addTag";
export const UPDATE_TAG_ROUTE = "updateTag";
export const DELETE_TAG_ROUTE = "deleteTag";

//ads API Routes
export const GET_ADS_ROUTE = "getAds";
export const ADD_AD_ROUTE = "addAd";
export const UPDATE_AD_ROUTE = "updateAd";
export const DELETE_AD_ROUTE = "deleteAd";

//get DATA
export const GET_DATA_ROUTE = "getData";

export const GET_FILES_ROUTE = "getFiles";
export const ADD_FILE_ROUTE = "addFile";
export const UPDATE_FILE_ROUTE = "updateFile";
export const DELETE_FILE_ROUTE = "deleteFile";
export const UPLOAD_FILE_ROUTE = "uploadFile";
